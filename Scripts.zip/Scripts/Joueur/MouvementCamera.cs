using System.Collections;
using Cinemachine;
using UnityEngine;
using UnityEngine.InputSystem;
 
public class MouvementCamera : MonoBehaviour
{
    [SerializeField] private float _sensibiliteYSouris = 50;
    [SerializeField] private float _sensibiliteXSouris = .2f;
    [SerializeField] private float _sensibiliteYManette = .2f;
    [SerializeField] private float _sensibiliteXManette = .2f;
    [SerializeField] CinemachineVirtualCamera _camera;
    [SerializeField] CinemachineVirtualCamera _cameraCinematique;
    [SerializeField] Transform _lookAtCinematique;
    float _sensibiliteY;
    float _sensibiliteX;
 
    private Vector2 _inputCamera;
    private float _rotationCameraX = 0;
    public CinemachineVirtualCamera Camera => _camera;
 
    private void OnLook(InputValue valeur)
    {
        _inputCamera = valeur.Get<Vector2>();
    }
 
    private void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        OnControlsChanged(GetComponent<PlayerInput>());
    }

    private void LateUpdate()
    {
        Vector2 vecteurSouris = _inputCamera * _sensibiliteY * Time.deltaTime;
        _rotationCameraX -= vecteurSouris.y;
        _rotationCameraX = Mathf.Clamp(_rotationCameraX, -90, 90);
 
        _camera.transform.localRotation = Quaternion.Euler(_rotationCameraX, 0f, 0f);
        transform.Rotate(Vector3.up * _inputCamera.x * _sensibiliteX);
    }

    void OnControlsChanged(PlayerInput playerInput)
    {
        _sensibiliteY = playerInput.currentControlScheme == "Gamepad" ? _sensibiliteYManette : _sensibiliteYSouris;
        _sensibiliteX = playerInput.currentControlScheme == "Gamepad" ? _sensibiliteXManette : _sensibiliteXSouris;
    }
 
    public void FaireTremblerCamera(bool activer, float force = 0, float frequence = 0)
    {
        if (_camera == null)
        {
            Debug.LogError("La référence à la caméra Cinemachine est NULL !");
            return;
        }
 
        CinemachineBasicMultiChannelPerlin noise = _camera.GetCinemachineComponent<CinemachineBasicMultiChannelPerlin>();
 
        // Si le composant Noise n'existe pas, on l'ajoute
        if (noise == null)
        {
            Debug.LogWarning("Aucun composant Noise trouvé, ajout automatique...");
            _camera.AddCinemachineComponent<CinemachineBasicMultiChannelPerlin>();
            noise = _camera.GetCinemachineComponent<CinemachineBasicMultiChannelPerlin>();
        }
 
        // Appliquer les valeurs
        noise.m_AmplitudeGain = activer ? force : 0;
        noise.m_FrequencyGain = activer ? frequence : 0;
    }
 
    public void ActiverDesactiverCameraPrincipale(bool activer, Transform lookAt = null)
    {
        _camera.Priority = activer ? 10 : 0;
        _cameraCinematique.Priority = activer ? 0 : 10;
 
        _cameraCinematique.LookAt = lookAt;
    }

    public void CiblerCinematique(){
        _cameraCinematique.LookAt = _lookAtCinematique;
    }
 
 
    public void ActiverCameraCinematique(Transform lookAt)
    {
        ActiverDesactiverCameraPrincipale(false, lookAt);
    }
}