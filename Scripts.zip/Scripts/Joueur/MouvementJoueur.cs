using System.Collections;
using Cinemachine;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

public class MouvementJoueur : MonoBehaviour
{
    [SerializeField] private float _vitesseMarche = 3f;
    [SerializeField] private float _vitesseCourse = 6f;
    [SerializeField] private float _gravite = 2f;

    [Header("Course")]
    [SerializeField] private float _dureeCourse = 5f;
    [SerializeField] private float _vitesseRechargeCourse = 2f;
    [SerializeField] private float _tempsDecelerationCourse = 2f;
    [SerializeField] private float _delaiPeutRecourir = 0.5f;
    [SerializeField] private CinemachineVirtualCamera _camera;
    private CharacterController _controlleur;
    private PlayerInput _playerInput;
    private InputAction _actionCourse;
    GestionChaleur _gestionChaleur;
    private float _courseRestante;
    private Vector2 _inputMouvement;
    private bool _enCourse = false;
    private bool _enDeplacement = false;
    private bool _peutCourir = false;
    private bool _peutRecourir = true;
    private bool _enRecharge = false;
    private bool _peutBouger = true;
    private bool _aPasEncoreBouge = true;
    private bool _aPasEncoreCouru = true;
    private float _fovInitial;
    public bool EnCourse { get => _enCourse; }
    public bool EnCharge { get => _enRecharge; set => _enRecharge = value; }
    public bool PeutBouger { get => _peutBouger; set => _peutBouger = value; }
    [SerializeField] private AudioSource _boucleCourse;
    private bool _peutJouerCourse = false;
    [SerializeField] private AudioSource _boucleRecuperation;
    private bool _peutJouerRecuperation = false;
    private bool _peutJouerSonPas = true;
    private float _rythmePas = 0.6f;

    private void Awake()
    {
        _courseRestante = _dureeCourse;
        _playerInput = GetComponent<PlayerInput>();
        _gestionChaleur = GetComponent<GestionChaleur>();

        _actionCourse = _playerInput.actions["Sprint"];
        _actionCourse.performed += ctx => ActiverCourse();
        _actionCourse.canceled += ctx => DesactiverCourse();

        _controlleur = GetComponent<CharacterController>();

    }

    private void Start()
    {
        if (GameManager.instance != null)
        {
            GameManager.instance.OnCinematiqueChange += ActiverDesactiverJoueur;
        }
        _fovInitial = _camera.m_Lens.FieldOfView;

        GestionnaireControles.instance.AfficherControle("Deplacement");
    }

    private void ActiverDesactiverJoueur(bool enCours)
    {
        GetComponent<MouvementJoueur>().enabled = !enCours;
        GetComponent<MouvementCamera>().enabled = !enCours;
        GetComponent<InteractionUtilisables>().enabled = !enCours;
        GetComponent<InteractionDeclencheurs>().enabled = !enCours;
        GetComponent<PlayerInput>().enabled = !enCours;
        GetComponent<Rigidbody>().isKinematic = enCours;
        GetComponent<CharacterController>().enabled = !enCours;
        if (enCours)
        {
            StopCoroutine(GetComponent<GestionChaleur>().CoroutineChaleur());
        }
        else
        {
            StartCoroutine(GetComponent<GestionChaleur>().CoroutineChaleur());
        }
    }

    private void OnMove(InputValue valeur)
    {
        _inputMouvement = valeur.Get<Vector2>();
        _enDeplacement = _inputMouvement.magnitude > 0;

        if (_aPasEncoreBouge && _enDeplacement)
        {
            Debug.Log("Le joueur a bougé");
            GestionnaireControles.instance.MasquerControle("Deplacement");
            _aPasEncoreBouge = false;
            StartCoroutine(AfficherControlePrendreObjet());
        }

        // Si le joueur commence à se déplacer et que le sprint est actif, on le déclenche
        if (_enDeplacement)
        {
            DemarrerCourse();
        }
        else
        {
            StopperCourse();
        }
    }

    private IEnumerator JouerSonsPas()
    {
        while (_enDeplacement && _peutJouerSonPas)
        {
            _peutJouerSonPas = false;
            RaycastHit hit;
            if (Physics.Raycast(transform.position - Vector3.up, Vector3.down, out hit, 1f))
            {
                if (hit.collider is TerrainCollider)
                {
                    GestionnaireAudio.instance.JouerSon(GestionnaireAudio.instance.neige[Random.Range(0, GestionnaireAudio.instance.neige.Length)], .2f, 0.8f, 1.2f);
                }
                else if (hit.collider.gameObject.CompareTag("Glace"))
                {
                    GestionnaireAudio.instance.JouerSon(GestionnaireAudio.instance.glace[Random.Range(0, GestionnaireAudio.instance.glace.Length)], .2f, 0.8f, 1.2f);
                }
                else
                {
                    GestionnaireAudio.instance.JouerSon(GestionnaireAudio.instance.plancher[Random.Range(0, GestionnaireAudio.instance.plancher.Length)], .6f, 0.8f, 1.2f);
                }
            }

            // SonsCourse();

            yield return new WaitForSeconds(_rythmePas);
            _peutJouerSonPas = true;
        }
    }

    private void JouerSonsCourse()
    {
        if (_peutJouerCourse)
        {
            _peutJouerCourse = false;
            _boucleCourse.Play();
        }
        else
        {
            if (!_enCourse) _boucleCourse.Stop();
        }

        if (_peutJouerRecuperation)
        {
            _peutJouerRecuperation = false;
            _boucleRecuperation.Play();
        }
        else
        {

            if (_enCourse || _courseRestante >= _dureeCourse) _boucleRecuperation.Stop();
        }
    }

    private IEnumerator AfficherControlePrendreObjet()
    {
        yield return new WaitForSeconds(1.5f);
        GestionnaireControles.instance.AfficherControle("Prendre/UtiliserObjet");
    }

    private void Update()
    {
        if (_peutBouger)
        {
            // Vector3 VecteurMouvement = transform.right * _inputMouvement.x + transform.forward * _inputMouvement.y - transform.up * _gravite;
            Vector3 VecteurMouvement = transform.right * _inputMouvement.x + transform.forward * _inputMouvement.y;
            VecteurMouvement -= transform.up * _gravite;
            _controlleur.Move(VecteurMouvement * (_enCourse ? _vitesseCourse : _vitesseMarche) * Time.deltaTime);
            _rythmePas = 0.1f;
            _rythmePas *= _enCourse ? _vitesseMarche : _vitesseCourse;
            if (_enDeplacement)
            {
                StartCoroutine(JouerSonsPas());
        }
    }
        JouerSonsCourse();
    }

    private void ActiverCourse()
    {
        _peutCourir = true;
        DemarrerCourse();
    }

    void DesactiverCourse()
    {
        _peutCourir = false;
        StopperCourse();
    }

    private void StopperCourse()
    {
        _enCourse = false;
        _peutJouerCourse = false;
        if (!_enDeplacement && !_peutCourir)
        {
            return;
        }
        StopAllCoroutines();
        _peutJouerSonPas = true;
        StartCoroutine(RechargerCourse());
    }

    private void DemarrerCourse()
    {
        if (_enDeplacement && _peutCourir && _peutRecourir) // Ajout de !_enCourse pour éviter les doublons
        {
            GameManager gameManager = GameManager.instance;
            if (gameManager && gameManager.estSortiDeZoneCourse && _aPasEncoreCouru)
            {
                GestionnaireControles.instance.MasquerControle("Courir");
                _aPasEncoreCouru = false;
            }
            _enCourse = true;
            _peutJouerCourse = true;
            Monstre monstre = Monstre.Instance;
            if (monstre && monstre.JoueurEstDansZoneEcoute)
            {
                Debug.Log("Le monstre a entendu le joueur");
                monstre.RemplacerPointActuel(transform);
            }
            StopAllCoroutines();
            _peutJouerSonPas = true;

            if (_enRecharge)
            {
                _gestionChaleur.DefinirVitesse("Epuise", false);
                _enRecharge = false;
                _peutJouerRecuperation = false;
            }

            _gestionChaleur.DefinirVitesse("Course", true);
            StartCoroutine(Course());
            _peutRecourir = false;
        }
    }

    private IEnumerator Course()
    {
        float duree = .3f;
        float tempsEcoule = 0;
        while (tempsEcoule < duree)
        {
            tempsEcoule += Time.deltaTime;
            _camera.m_Lens.FieldOfView = Mathf.Lerp(_fovInitial, _fovInitial + 20, tempsEcoule / duree);
            yield return null;
        }

        _camera.m_Lens.FieldOfView = _fovInitial + 20;

        while (_enCourse && _courseRestante > 0)
        {
            _courseRestante -= Time.deltaTime;
            yield return null;
        }

        if (_courseRestante <= 0)
        {
            StartCoroutine(RalentirCourse());
        }
    }

    private IEnumerator RalentirCourse()
    {
        _enCourse = false;
        _peutJouerCourse = false;
        StartCoroutine(RechargerCourse());
        float tempsEcoule = 0;

        while (tempsEcoule < _tempsDecelerationCourse)
        {
            tempsEcoule += Time.deltaTime;
            if (!_enDeplacement)
            {
                yield break;
            }
            yield return null;
        }
    }

    private IEnumerator RechargerCourse()
    {
        StartCoroutine(Recourir());

        _gestionChaleur.DefinirVitesse("Course", false);
        _gestionChaleur.DefinirVitesse("Epuise", true);

        float duree = .3f;
        float tempsEcoule = 0;
        while (tempsEcoule < duree)
        {
            tempsEcoule += Time.deltaTime;
            _camera.m_Lens.FieldOfView = Mathf.Lerp(_fovInitial + 20, _fovInitial, tempsEcoule / duree);
            yield return null;
        }

        _camera.m_Lens.FieldOfView = _fovInitial;

        while (_peutCourir && _enDeplacement)
        {
            yield return null;
        }
        _enRecharge = true;
        _peutJouerRecuperation = true;

        while (_courseRestante < _dureeCourse && !_enCourse)
        {
            _courseRestante += Time.deltaTime * _vitesseRechargeCourse;
            yield return null;
        }
        _gestionChaleur.DefinirVitesse("Epuise", false);
        _enRecharge = false;
        _peutJouerRecuperation = false;
    }

    IEnumerator Recourir()
    {
        yield return new WaitForSeconds(_delaiPeutRecourir);
        _peutRecourir = true;
        DemarrerCourse();
    }

    public void ReinitialiserJoueur()
    {
        _courseRestante = _dureeCourse;
        _camera.m_Lens.FieldOfView = _fovInitial;
        _enCourse = false;
        _peutJouerCourse = false;
        _enDeplacement = false;
        _peutCourir = false;
        _enRecharge = false;
        _peutJouerRecuperation = false;
    }
}
