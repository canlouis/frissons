using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.UI;
 
public class GestionChaleur : MonoBehaviour
{
    [Header("Gestion chaleur")]
    [SerializeField] private float _chaleurMax = 100f;
    [SerializeField] private float _vitessePCBase = 1f;
    [SerializeField] private float _vitesseChaleurCourse = 1f;
    [SerializeField] private float _vitessePCEpuise = 2f;
    [SerializeField] private float _vitesseChaleurLampe = 1f;
    [SerializeField] CanvasGroup _mort;
    [SerializeField] float _tempsMort = 2f;
    [SerializeField] Volume _volume;
 
    private float _chaleurActuelle = 100f;
    private bool _peutChangerVitesse = true;
    bool _estMort = false;
 
    private Dictionary<string, float> _typesVitesse = new Dictionary<string, float>();
    private Dictionary<string, bool> _etatsVitesse = new Dictionary<string, bool>();
 
    // 🆕 Liste pour stocker les valeurs des différentes zones de monstre
    private Dictionary<GameObject, float> _zonesActives = new Dictionary<GameObject, float>();
 
    private float _vitesseActuellePC;
    private Vignette _vignette; // Ajoutez cette ligne pour stocker la référence à l'effet de vignette
    // private ColorAdjustments _couleurs; // Ajoutez cette ligne pour stocker la référence à l'effet de vignette
    public float VitessePCBase => _vitessePCBase;
    public float VitessePCCourse => _vitesseChaleurCourse;
    public float VitessePCEpuise => _vitessePCEpuise;
    public bool PeutChangerVitesse { get => _peutChangerVitesse; set => _peutChangerVitesse = value; }
    public bool EstMort { get => _estMort; set => _estMort = value; }
 
    private void Start()
    {
        // Obtenez la référence à l'effet de vignette
        if (_volume.profile.TryGet<Vignette>(out _vignette))
        {
            _vignette.intensity.overrideState = true;
        }
 
        // if (_volume.profile.TryGet<ColorAdjustments>(out _couleurs))
        // {
        //     _couleurs.postExposure.overrideState = true;
        //     _couleurs.contrast.overrideState = true;
        //     _couleurs.colorFilter.overrideState = true;
        //     _couleurs.saturation.overrideState = true;
        // }
    }
 
    public void Commencer()
    {
        _chaleurActuelle = _chaleurMax;
        _vitesseActuellePC = _vitessePCBase;
        AjouterVitesse("Course", -_vitesseChaleurCourse, false);
        AjouterVitesse("Epuise", _vitessePCEpuise, false);
        AjouterVitesse("Lampe", -_vitesseChaleurLampe, false);
        RecalculerVitesseActuellePC();
        StartCoroutine(CoroutineChaleur());
    }
 
    public IEnumerator CoroutineChaleur()
    {
        while (_chaleurActuelle > 0)
        {
            _chaleurActuelle = Mathf.Clamp(_chaleurActuelle - _vitesseActuellePC * Time.deltaTime, 0, _chaleurMax);
 
            // Ajustez l'intensité de la vignette en fonction de la chaleur restante
            if (_vignette != null)
            {
                _vignette.intensity.value = (1 - _chaleurActuelle / _chaleurMax) / 2;
            }
            // if (_couleurs != null)
            // {
            //     _couleurs.postExposure.value = (1 - _chaleurActuelle / _chaleurMax) * 2;
            //     _couleurs.contrast.value = (1 - _chaleurActuelle / _chaleurMax) * -20;
            //     _couleurs.saturation.value = (1 - _chaleurActuelle / _chaleurMax) * -30;
            // }
 
            if (_chaleurActuelle < _chaleurMax / 2 + .5f && _chaleurActuelle > _chaleurMax / 2 - .5f)
            {
                GestionnaireSousTitres.instance.JouerDialogue("MoitieChaleur");
            }
            else if (_chaleurActuelle < _chaleurMax / 4 + .5f && _chaleurActuelle > _chaleurMax / 4 - .5f)
            {
                GestionnaireSousTitres.instance.JouerDialogue("ChaleurBasse");
            }
            yield return null;
        }
        StartCoroutine(CoroutineMort());
    }
 
    public void RepartirCoroutineChaleur()
    {
        StartCoroutine(CoroutineChaleur());
    }
 
    private void RecalculerVitesseActuellePC()
    {
        if (!_peutChangerVitesse) return;
 
        // Debug.Log("Recalcul de la vitesse actuelle...");
 
        _vitesseActuellePC = _vitessePCBase;
 
        // Additionne toutes les vitesses actives normales
        foreach (var type in _etatsVitesse)
        {
            if (type.Value)
            {
                _vitesseActuellePC += _typesVitesse[type.Key];
            }
        }
 
        // Additionne les effets des zones de monstre
        foreach (var zone in _zonesActives.Values)
        {
            _vitesseActuellePC += zone;
        }
    }
 
    IEnumerator CoroutineMort()
    {
        _estMort = true;
        float tempsEcoule = 0;
        while (tempsEcoule < _tempsMort)
        {
            tempsEcoule += Time.deltaTime;
            _mort.alpha = tempsEcoule / _tempsMort;
            yield return null;
        }
        GestionnaireAudio.instance.JouerSon(GestionnaireAudio.instance.mort, 1, .8f, 1.2f);
        yield return new WaitForSeconds(.5f);
        Checkpoint.Instance.RestaurerDernierCheckpoint(gameObject);
    }
 
    IEnumerator CoroutineReveil()
    {
        float tempsEcoule = 0;
        while (tempsEcoule < _tempsMort)
        {
            tempsEcoule += Time.deltaTime;
            _mort.alpha = 1 - tempsEcoule / _tempsMort;
            yield return null;
        }
        _mort.alpha = 0;
        _estMort = false;
    }
 
    public void DefinirVitesse(string type, bool actif)
    {
        if (_etatsVitesse.ContainsKey(type))
        {
            _etatsVitesse[type] = actif;
            RecalculerVitesseActuellePC();
        }
    }
 
    public void AjouterVitesse(string type, float valeur, bool actifParDefaut = false)
    {
        if (!_typesVitesse.ContainsKey(type))
        {
            _typesVitesse.Add(type, valeur);
            _etatsVitesse.Add(type, actifParDefaut);
            RecalculerVitesseActuellePC();
        }
    }
 
    public void SupprimerVitesse(string type)
    {
        if (_typesVitesse.ContainsKey(type))
        {
            _typesVitesse.Remove(type);
            _etatsVitesse.Remove(type);
            RecalculerVitesseActuellePC();
        }
    }
 
    public void ModifierVitessePC(float vitesse)
    {
        _vitesseActuellePC = vitesse;
    }
 
    public void ReinitialiserJoueur()
    {
        _chaleurActuelle = _chaleurMax;
        _vitesseActuellePC = _vitessePCBase;
 
        // Créer une copie des clés pour éviter l'erreur de modification
        List<string> cles = new List<string>(_etatsVitesse.Keys);
 
        // Réinitialiser les valeurs à false
        foreach (var cle in cles)
        {
            _etatsVitesse[cle] = false;
        }
 
        _peutChangerVitesse = true;
 
        _vignette.intensity.value = 0;
        // _couleurs.postExposure.value = 0;
        // _couleurs.contrast.value = 0;
        // _couleurs.colorFilter.value = Color.white;
        // _couleurs.saturation.value = 0;
 
        StartCoroutine(CoroutineReveil());
        StartCoroutine(CoroutineChaleur());
    }
 
    public void SortiZone(float vitesse)
    {
        _peutChangerVitesse = true;
        _vitesseActuellePC -= vitesse;
        RecalculerVitesseActuellePC();
    }
}