using System.Collections.Generic;
using Unity.Mathematics;
using UnityEngine;
using UnityEngine.InputSystem;

public class InteractionDeclencheurs : MonoBehaviour
{
    [SerializeField] private float _distanceInteraction = 2f;

    private PlayerInput _playerInput;
    private InputAction _actionMainDroite;
    private InputAction _actionMainGauche;
    private Declencheur _declencheurCible;

    private InteractionUtilisables _interactionUtilisables;

    public Declencheur declencheurCible { get => _declencheurCible; set => _declencheurCible = value; }

    private void Awake()
    {
        _playerInput = GetComponent<PlayerInput>();
        _interactionUtilisables = GetComponent<InteractionUtilisables>();
        _actionMainDroite = _playerInput.actions["RightHand"];
        _actionMainDroite.performed += ctx => ConsommerUtilisable(true);
        _actionMainGauche = _playerInput.actions["LeftHand"];
        _actionMainGauche.performed += ctx => ConsommerUtilisable(false);
    }
    private void Update()
    {
        CiblerDeclencheur();
    }

    private void CiblerDeclencheur()
    {
        Ray rayon = Camera.main.ScreenPointToRay(new Vector3(Screen.width / 2, Screen.height / 2, 0));
        RaycastHit[] detectionsArray = Physics.RaycastAll(rayon, _distanceInteraction);
        List<RaycastHit> detections = new List<RaycastHit>(detectionsArray);

        // Trier par distance pour être sûr de traiter l'objet le plus proche en premier
        detections.Sort((hit1, hit2) => hit1.distance.CompareTo(hit2.distance));

        // Ignorer le joueur s'il est en premier plan
        if (detections.Count > 0 && detections[0].collider.CompareTag("Joueur"))
            detections.RemoveAt(0);

        Declencheur nouveauDeclencheurCible = null;

        foreach (var detection in detections)
        {
            if (detection.collider.CompareTag("Mur"))
            {
                nouveauDeclencheurCible = null; // Bloqué par un mur, on ne sélectionne rien
                break;
            }

            if (detection.collider.GetComponent<Declencheur>())
            {
                nouveauDeclencheurCible = detection.collider.GetComponent<Declencheur>();
                break;
            }
        }

        // Si l'objet ciblé change, mettre à jour l'affichage
        if (_declencheurCible != nouveauDeclencheurCible)
        {
            if (_declencheurCible != null)
            {
                _declencheurCible.DesactiverContour();
                GestionnaireSousTitres.instance.AfficherInteraction("");
            }

            _declencheurCible = nouveauDeclencheurCible;

            if (_declencheurCible != null)
            {
                _declencheurCible.ActiverContour();
                GestionnaireSousTitres.instance.AfficherInteraction(_declencheurCible.nom);
            }
        }

    }


    private void ConsommerUtilisable(bool estMainDroite)
    {
        if (!_declencheurCible) return;
        if (!_interactionUtilisables) return;
        if (Keyboard.current.ctrlKey.isPressed) return;
        if (estMainDroite)
        {
            if (_interactionUtilisables.utilisableMainDroite)
            {
                if (_declencheurCible.ConsommerUtilisable(_interactionUtilisables.utilisableMainDroite))
                    _interactionUtilisables.utilisableMainDroite.Consommer(_interactionUtilisables);
                if (_interactionUtilisables.utilisableMainDroite && _interactionUtilisables.utilisableMainGauche && _declencheurCible)
                {
                    GestionnaireSousTitres.instance.JouerDialogue("MainsPleines");
                }
                return;
            }
        }
        else
        {
            if (_interactionUtilisables.utilisableMainGauche)
            {
                if (_declencheurCible.ConsommerUtilisable(_interactionUtilisables.utilisableMainGauche))
                    _interactionUtilisables.utilisableMainGauche.Consommer(_interactionUtilisables);
                return;
            }
        }


        if (_declencheurCible) _declencheurCible.Declencher(this);
    }
}
