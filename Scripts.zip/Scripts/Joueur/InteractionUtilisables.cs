using Unity.Mathematics;
using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections.Generic;
using System.Collections;

public class InteractionUtilisables : MonoBehaviour, SauvegardeEtat
{
    [SerializeField] private float _distanceInteraction = 2f;
    [SerializeField] private float _forceLancer = 6f;
    [SerializeField] private Transform _mainDroite;
    [SerializeField] private Transform _mainGauche;
    [SerializeField] private LayerMask _calques_depot;

    private PlayerInput _playerInput;
    private InputAction _actionMainDroite;
    private InputAction _actionMainGauche;
    private InputAction _actionDeposerDroite;
    private InputAction _actionDeposerGauche;
    private Utilisable _utilisableMainDroite;
    private Utilisable _utilisableMainGauche;
    private Utilisable _utilisableCible;

    private bool _peutDeposer = true;
    bool _aRienPris = true;
    bool _aRienDepose = false;

    public Utilisable utilisableCible { get => _utilisableCible; set => _utilisableCible = value; }
    public Utilisable utilisableMainDroite { get => _utilisableMainDroite; set => _utilisableMainDroite = value; }
    public Utilisable utilisableMainGauche { get => _utilisableMainGauche; set => _utilisableMainGauche = value; }

    private InteractionDeclencheurs _interactionDeclencheurs;

    private void Awake()
    {
        _playerInput = GetComponent<PlayerInput>();
        _interactionDeclencheurs = GetComponent<InteractionDeclencheurs>();
        _actionDeposerDroite = _playerInput.actions["DropRightHand"];
        _actionDeposerGauche = _playerInput.actions["DropLeftHand"];
        _actionDeposerDroite.performed += ctx => DeposerUtilisable(true);
        _actionDeposerGauche.performed += ctx => DeposerUtilisable(false);

        _actionMainDroite = _playerInput.actions["RightHand"];
        _actionMainGauche = _playerInput.actions["LeftHand"];
        _actionMainDroite.performed += ctx => PrendreUtilisable(true);
        _actionMainGauche.performed += ctx => PrendreUtilisable(false);
    }

    public Dictionary<string, object> SauvegarderEtat()
    {
        // Implement the method to save the state
        return new Dictionary<string, object>();
    }

    public void RestaurerEtat(Dictionary<string, object> etat)
    {
        // Implement the method to restore the state
    }

    private void Update()
    {
        CiblerUtilisable();
    }

    private void LateUpdate()
    {
        _peutDeposer = true;
    }

    private void PrendreUtilisable(bool estMainDroite)
    {
        if (Keyboard.current.ctrlKey.isPressed) return;


        Vector3 positionTemp;
        Vector3 rotationTemp;
        Vector3 scaleTemp;

        if (estMainDroite)
        {
            if (_utilisableMainDroite)
            {
                if (_utilisableMainDroite && _utilisableMainGauche && _utilisableCible)
                {
                    GestionnaireSousTitres.instance.JouerDialogue("MainsPleines");
                }
                if (_interactionDeclencheurs.declencheurCible) return;
                if (_utilisableMainDroite is not Allumette) _utilisableMainDroite.Utiliser(this);
                if (_utilisableMainDroite.typeConsomable == "Flamme" && _utilisableMainGauche is Lampe)
                {
                    if (_utilisableMainDroite is Lampe && _utilisableMainDroite.GetComponent<Lampe>().estAllume) return;
                    _utilisableMainGauche.GetComponent<Lampe>().AllumerLampe(_utilisableMainDroite);
                }
                return;
            }
            if (!_utilisableCible) return;
            _utilisableMainDroite = _utilisableCible;
            _utilisableCible.transform.SetParent(_mainDroite);
            _utilisableMainDroite.Prendre(this);

            positionTemp = new Vector3(-_utilisableCible.ancre.localPosition.x, _utilisableCible.ancre.localPosition.y, _utilisableCible.ancre.localPosition.z);
            rotationTemp = new Vector3(_utilisableCible.ancre.localRotation.eulerAngles.x, -_utilisableCible.ancre.localRotation.eulerAngles.y, -_utilisableCible.ancre.localRotation.eulerAngles.z);
            scaleTemp = _utilisableCible.ancre.localScale;
        }
        else
        {
            if (_utilisableMainGauche)
            {
                if (_interactionDeclencheurs.declencheurCible) return;
                if (_utilisableMainGauche is not Allumette) _utilisableMainGauche.Utiliser(this);
                if (_utilisableMainGauche.typeConsomable == "Flamme" && _utilisableMainDroite is Lampe)
                {
                    if (_utilisableMainGauche is Lampe && _utilisableMainGauche.GetComponent<Lampe>().estAllume) return;
                    _utilisableMainDroite.GetComponent<Lampe>().AllumerLampe(_utilisableMainGauche);
                }
                return;
            }
            if (!_utilisableCible) return;
            _utilisableMainGauche = _utilisableCible;
            _utilisableCible.transform.SetParent(_mainGauche);
            _utilisableMainGauche.Prendre(this);

            positionTemp = _utilisableCible.ancre.localPosition;
            rotationTemp = _utilisableCible.ancre.localRotation.eulerAngles;
            scaleTemp = _utilisableCible.ancre.localScale;
        }
        GestionnaireAudio.instance.JouerSon(GestionnaireAudio.instance.prendre, 1, .8f, 1.2f, _utilisableCible.transform.position);

        if (_aRienPris)
        {
            GestionnaireControles.instance.MasquerControle("Prendre/UtiliserObjet");
            _aRienPris = false;
            StartCoroutine(AfficherControleDeposerObjet());
        }

        if (_utilisableCible.GetComponent<Lampe>() && _utilisableCible.GetComponent<Lampe>().estAllume) GetComponent<GestionChaleur>().DefinirVitesse("Lampe", true);
        _peutDeposer = false;
        GestionnaireAudio.instance.JouerSon(_utilisableCible.son_prendre, .8f, 1.2f, .5f, transform.position);
        _utilisableCible.DesactiverContour();
        GestionnaireSousTitres.instance.AfficherInteraction("");
        _utilisableCible.gameObject.layer = LayerMask.NameToLayer("Mains");
        foreach (Transform enfant in _utilisableCible.transform)
        {
            enfant.gameObject.layer = LayerMask.NameToLayer("Mains");
            foreach (Transform petitEnfant in enfant)
            {
                petitEnfant.gameObject.layer = LayerMask.NameToLayer("Mains");
            }
        }
        _utilisableCible.GetComponent<Rigidbody>().isKinematic = true;
        _utilisableCible.GetComponent<Collider>().enabled = false;
        _utilisableCible.transform.localPosition = positionTemp;
        _utilisableCible.transform.localRotation = Quaternion.Euler(rotationTemp);
        _utilisableCible.transform.localScale = scaleTemp;
        _utilisableCible.Prendre(this);
        _utilisableCible = null;
    }

    private IEnumerator AfficherControleDeposerObjet()
    {
        yield return new WaitForSeconds(1.5f);
        GestionnaireControles.instance.AfficherControle("Deposer/JeterObjet");
        _aRienDepose = true;
    }

    public void ReinitialiserUtilisables(Utilisable utilisable, bool estMainDroite)
    {
        Vector3 positionTemp;
        Vector3 rotationTemp;
        Vector3 scaleTemp;
        if (estMainDroite)
        {
            _utilisableMainDroite = utilisable;
            utilisable.transform.SetParent(_mainDroite);
            scaleTemp = utilisable.ancre.localScale;
            positionTemp = new Vector3(-utilisable.ancre.localPosition.x, utilisable.ancre.localPosition.y, utilisable.ancre.localPosition.z);
            rotationTemp = new Vector3(utilisable.ancre.localRotation.eulerAngles.x, -utilisable.ancre.localRotation.eulerAngles.y, -utilisable.ancre.localRotation.eulerAngles.z);
        }
        else
        {
            _utilisableMainGauche = utilisable;
            utilisable.transform.SetParent(_mainGauche);
            scaleTemp = utilisable.ancre.localScale;
            positionTemp = utilisable.ancre.localPosition;
            rotationTemp = utilisable.ancre.localRotation.eulerAngles;
        }
        if (utilisable.GetComponent<Lampe>() && utilisable.GetComponent<Lampe>().estAllume) GetComponent<GestionChaleur>().DefinirVitesse("Lampe", true);
        _peutDeposer = false;
        utilisable.DesactiverContour();
        GestionnaireSousTitres.instance.AfficherInteraction("");
        utilisable.gameObject.layer = LayerMask.NameToLayer("Mains");
        foreach (Transform enfant in utilisable.transform)
        {
            enfant.gameObject.layer = LayerMask.NameToLayer("Mains");
            foreach (Transform petitEnfant in enfant)
            {
                petitEnfant.gameObject.layer = LayerMask.NameToLayer("Mains");
            }
        }
        utilisable.GetComponent<Rigidbody>().isKinematic = true;
        utilisable.GetComponent<Collider>().enabled = false;
        utilisable.transform.localPosition = positionTemp;
        utilisable.transform.localRotation = Quaternion.Euler(rotationTemp);
        utilisable.transform.localScale = scaleTemp;
    }

    public void DeposerUtilisable(bool estMainDroite)
    {
        Ray rayon = Camera.main.ScreenPointToRay(new Vector3(Screen.width / 2, Screen.height / 2, 0));
        RaycastHit detection;

        Vector3 rotationTemp;
        Vector3 scaleTemp = Vector3.one;

        if (!_peutDeposer) return;


        Utilisable utilisable;
        if (estMainDroite)
        {
            if (!_utilisableMainDroite) return;
            utilisable = _utilisableMainDroite;
            _utilisableMainDroite = null;
            utilisable.transform.position = _mainDroite.transform.position;
            utilisable.Deposer(this);

            rotationTemp = new Vector3(utilisable.ancre.localRotation.eulerAngles.x, -utilisable.ancre.localRotation.eulerAngles.y, -utilisable.ancre.localRotation.eulerAngles.z);

        }
        else
        {
            if (!_utilisableMainGauche) return;
            utilisable = _utilisableMainGauche;
            _utilisableMainGauche = null;
            utilisable.transform.position = _mainGauche.transform.position;
            utilisable.Deposer(this);

            rotationTemp = utilisable.ancre.rotation.eulerAngles;
        }
        GestionnaireAudio.instance.JouerSon(GestionnaireAudio.instance.deposer, 1, .8f, 1.2f);

        if (utilisable.GetComponent<Lampe>())
        {
            GetComponent<GestionChaleur>().DefinirVitesse("Lampe", false);
        }

        if (_aRienDepose)
        {
            GestionnaireControles.instance.MasquerControle("Deposer/JeterObjet");
            _aRienDepose = false;
        }

        utilisable.gameObject.layer = LayerMask.NameToLayer("Utilisable");
        foreach (Transform enfant in utilisable.transform)
        {
            enfant.gameObject.layer = LayerMask.NameToLayer("Utilisable");
            foreach (Transform petitEnfant in enfant)
            {
                petitEnfant.gameObject.layer = LayerMask.NameToLayer("Utilisable");
            }
        }
        utilisable.transform.SetParent(null);
        utilisable.GetComponent<Rigidbody>().isKinematic = false;
        utilisable.GetComponent<Collider>().enabled = true;
        utilisable.transform.rotation = Quaternion.Euler(transform.rotation.eulerAngles + rotationTemp);
        utilisable.transform.localScale = scaleTemp;
        GestionnaireAudio.instance.JouerSon(utilisable.son_deposer, .8f, 1.2f, .5f, transform.position);

        Vector3 direction = (Camera.main.transform.forward + (Camera.main.transform.up / 2f)).normalized;
        if (Physics.Raycast(rayon, out detection, Mathf.Infinity, _calques_depot))
        {
            Vector3 pointDeContact = detection.point;
            MeshRenderer meshRenderer = utilisable.meshRenderer;


            if ((transform.position - pointDeContact).magnitude < _distanceInteraction && meshRenderer != null)
            {
                Vector3 extents = meshRenderer.bounds.extents;
                Vector3 adjustedPosition = pointDeContact + detection.normal * extents.magnitude;
                utilisable.transform.position = adjustedPosition;
                return;
            }
            else
            {
                direction = (pointDeContact - utilisable.transform.position + (Camera.main.transform.up / 2)).normalized;
                utilisable.GetComponent<Rigidbody>().AddForce(direction * _forceLancer, ForceMode.Impulse);
            }
        }
        utilisable.GetComponent<Rigidbody>().AddForce(direction * _forceLancer, ForceMode.Impulse);
    }

    public void SupprimerUtilisable(Utilisable utilisable)
    {
        if (!utilisable) return;
        if (_utilisableMainDroite == utilisable)
        {
            DeposerUtilisable(true);
        }
        else if (_utilisableMainGauche == utilisable)
        {
            DeposerUtilisable(false);
        }
    }


    private void CiblerUtilisable()
    {
        Ray rayon = Camera.main.ScreenPointToRay(new Vector3(Screen.width / 2, Screen.height / 2, 0));
        RaycastHit[] detectionsArray = Physics.RaycastAll(rayon, _distanceInteraction);
        List<RaycastHit> detections = new List<RaycastHit>(detectionsArray);

        // Trier par distance pour être sûr de traiter l'objet le plus proche en premier
        detections.Sort((hit1, hit2) => hit1.distance.CompareTo(hit2.distance));

        // Ignorer le joueur s'il est en premier plan
        if (detections.Count > 0 && detections[0].collider.CompareTag("Joueur"))
            detections.RemoveAt(0);


        Utilisable nouvelUtilisableCible = null;

        foreach (var detection in detections)
        {
            if (detection.collider.CompareTag("Mur") || detection.collider.CompareTag("Porte"))
            {
                nouvelUtilisableCible = null; // Bloqué par un mur, on ne sélectionne rien
                break;
            }

            if (detection.collider.GetComponent<Utilisable>())
            {
                nouvelUtilisableCible = detection.collider.GetComponent<Utilisable>();
                break;
            }
        }

        // Si l'objet ciblé change, mettre à jour l'affichage
        if (_utilisableCible != nouvelUtilisableCible)
        {
            if (_utilisableCible != null)
            {
                _utilisableCible.DesactiverContour();
                GestionnaireSousTitres.instance.AfficherInteraction("");
            }

            _utilisableCible = nouvelUtilisableCible;

            if (_utilisableCible != null)
            {
                _utilisableCible.ActiverContour();
                GestionnaireSousTitres.instance.AfficherInteraction(_utilisableCible.nom);
            }
        }

    }
}
