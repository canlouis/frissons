using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class ObjetEtat
{
    private Vector3 position;
    private Quaternion rotation;
    private bool actif;
    private GameObject objet;
    bool _replacer = true;
    private Dictionary<string, object> etatPersonnalise; // ✅ Ajout d'un dictionnaire d'état
    LayerMask _layerMask;
    public GameObject Objet => objet;
    public bool Replacer { get => _replacer; set => _replacer = value; }

    public ObjetEtat(GameObject obj)
    {
        objet = obj;
        position = obj.transform.position;
        rotation = obj.transform.rotation;
        actif = obj.activeSelf;
        _layerMask = obj.layer;
        etatPersonnalise = new Dictionary<string, object>();

        // 🔹 Vérifier si l'objet possède des états spéciaux à sauvegarder
        SauvegardeEtat sauvegardable = obj.GetComponent<SauvegardeEtat>();
        if (sauvegardable != null)
        {
            etatPersonnalise = sauvegardable.SauvegarderEtat();
        }
    }

    public void Restaurer()
    {
        if (objet == null) return;

        // 🔹 Restaurer les états spécifiques
        SauvegardeEtat sauvegardable = objet.GetComponent<SauvegardeEtat>();
        if (sauvegardable != null)
        {
            sauvegardable.RestaurerEtat(etatPersonnalise);
        }
        objet.SetActive(actif);
        objet.layer = _layerMask;

        if(!_replacer) return;

        Rigidbody rb = objet.GetComponent<Rigidbody>();
        if (rb != null)
        {
            rb.velocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
            rb.isKinematic = true;
        }

        if (_replacer)
        {
            objet.transform.position = position;
            objet.transform.rotation = rotation;
        }


        if (rb != null)
        {
            objet.GetComponent<MonoBehaviour>().StartCoroutine(ReactiverPhysique(rb));
        }
    }

    public void ReactiverObjets()
    {
        if (objet == null) return;
        objet.SetActive(true);
    }

    private IEnumerator ReactiverPhysique(Rigidbody rb)
    {
        yield return new WaitForFixedUpdate();
        rb.isKinematic = false;
    }
}
