using System.Collections.Generic;

public interface SauvegardeEtat
{
    Dictionary<string, object> SauvegarderEtat();
    void RestaurerEtat(Dictionary<string, object> etat);
}

