using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;

public class TriggerScript : MonoBehaviour
{
    List<Vector3> enter_velocity = new List<Vector3>();
    ParticleSystem ps;

    void Start()
    {
        ps = GetComponent<ParticleSystem>();
    }


    void OnParticleTrigger()
    {
        if (!ps)
        {
            return;
        }
        
        for (int i = 0; i < ps.particleCount; i++)
        {
            enter_velocity.Add(Vector3.zero);
        }

        // particles
        List<ParticleSystem.Particle> enter = new List<ParticleSystem.Particle>();
        List<ParticleSystem.Particle> exit = new List<ParticleSystem.Particle>();

        // get
        int numEnter = ps.GetTriggerParticles(ParticleSystemTriggerEventType.Enter, enter, out var other_enter);
        int numExit = ps.GetTriggerParticles(ParticleSystemTriggerEventType.Exit, exit);

        // iterate
        for (int i = 0; i < numEnter; i++)
        {
            ParticleSystem.Particle p = enter[i];
            enter_velocity[i] = p.velocity;
            p.velocity = Vector3.zero;
            enter[i] = p;
        }
        for (int i = 0; i < numExit; i++)
        {
            ParticleSystem.Particle p = exit[i];
            // p.startColor = new Color32(0, 255, 0, 255);
            p.velocity = enter_velocity[i];
            exit[i] = p;
        }

        // set
        ps.SetTriggerParticles(ParticleSystemTriggerEventType.Enter, enter);
        ps.SetTriggerParticles(ParticleSystemTriggerEventType.Exit, exit);
    }
}