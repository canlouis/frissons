using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Monstre : MonoBehaviour
{
    static Monstre _instance;
    public static Monstre Instance => _instance;
    [SerializeField] private Transform[] _pointsDePatrouille;
    [SerializeField] private int _nbPointsEnMemoire = 4;
    [SerializeField] Transform _joueur;
    [SerializeField] float _vitesseRecalculerPosJoueur = 1.5f;
    [SerializeField] float _vitesseDeplacement = 10f;
    [SerializeField] GameObject _corpsMonstre;
    List<Transform> _pointsDePatrouilleListe = new();
    List<Transform> _pointsDePatrouilleActuels = new();
    Vector3 _tailleInitiale;
    Light _lumiere;
    float _intensiteLumiereInitiale;
    bool _estDistrait = false;
    bool _peutAjouterJoueur = false;
    bool _joueurEstDansZoneEcoute = false;
    bool _peutSeDeplacer = true;
    bool _aEteActive = false;
    public bool PeutAjouterJoueur { get => _peutAjouterJoueur; set => _peutAjouterJoueur = value; }
    public bool JoueurEstDansZoneEcoute { get => _joueurEstDansZoneEcoute; set => _joueurEstDansZoneEcoute = value; }
    public bool PeutSeDeplacer { get => _peutSeDeplacer; set => _peutSeDeplacer = value; }
    public bool EstDistrait { get => _estDistrait; set => _estDistrait = value; }

    void Awake()
    {
        if (_instance == null)
        {
            _instance = this;
        }
        else if (_instance != this)
        {
            Destroy(gameObject);
        }

        _lumiere = GetComponent<Light>();
        _tailleInitiale = transform.localScale;
        _intensiteLumiereInitiale = _lumiere.intensity;

        foreach (Transform point in _pointsDePatrouille)
        {
            _pointsDePatrouilleListe.Add(point);
        }

        for (int i = 0; i < _nbPointsEnMemoire; i++)
        {
            _pointsDePatrouilleActuels.Add(_pointsDePatrouille[Random.Range(0, _pointsDePatrouilleListe.Count - 1)]);
            _pointsDePatrouilleListe.Remove(_pointsDePatrouilleActuels[i]);
        }
    }

    public void ActiverMonstre()
    {
        _aEteActive = true;
        _lumiere.enabled = true;
        foreach (Transform enfant in transform)
        {
            enfant.gameObject.SetActive(true);
        }

        StartCoroutine(AllerVers(_pointsDePatrouilleActuels[0].position));
    }

    void ChoisirPointSuivant()
    {
        if (_joueurEstDansZoneEcoute && _joueur.GetComponent<MouvementJoueur>().EnCourse)
        {
            RemplacerPointActuel(_joueur);
        }
        else if (_peutAjouterJoueur)
        {
            // Prends le point de patrouille le plus proche du joueur
            for (int i = 0; i < _pointsDePatrouilleListe.Count; i++)
            {
                if (Vector3.Distance(_joueur.position, _pointsDePatrouilleListe[i].position) < Vector3.Distance(_joueur.position, _pointsDePatrouilleListe[0].position))
                {
                    _pointsDePatrouilleActuels.Add(_pointsDePatrouilleListe[i]);
                    _pointsDePatrouilleListe.RemoveAt(i);
                }
                else
                {
                    _pointsDePatrouilleActuels.Add(_pointsDePatrouilleListe[0]);
                    _pointsDePatrouilleListe.RemoveAt(0);
                }
            }
        }
        else
        {
            int posRandom = Random.Range(0, _pointsDePatrouilleListe.Count);
            _pointsDePatrouilleActuels.Add(_pointsDePatrouilleListe[posRandom]);
            _pointsDePatrouilleListe.RemoveAt(posRandom);
        }

        if (new List<Transform>(_pointsDePatrouille).Contains(_pointsDePatrouilleActuels[0])) _pointsDePatrouilleListe.Add(_pointsDePatrouilleActuels[0]);
        _pointsDePatrouilleActuels.RemoveAt(0);
        _peutAjouterJoueur = false;
    }

    public void RemplacerPointActuel(Transform point)
    {
        if (_estDistrait) return;
        StopAllCoroutines(); // Arrête proprement les coroutines
        if (point != _joueur) _estDistrait = true;
        _pointsDePatrouilleActuels.Insert(0, point);
        if (point == _joueur)
        {
            StartCoroutine(CoroutineRechercheJoueur());
        }

        StartCoroutine(AllerVers(_pointsDePatrouilleActuels[0].position));
    }

    IEnumerator CoroutineRechercheJoueur()
    {
        yield return new WaitForSeconds(_vitesseRecalculerPosJoueur);
        if (_joueurEstDansZoneEcoute && _joueur.GetComponent<MouvementJoueur>().EnCourse)
        {
            RemplacerPointActuel(_joueur);
        }
    }

    private IEnumerator AllerVers(Vector3 positionCible)
    {
        Rigidbody rb = GetComponent<Rigidbody>();
        rb.isKinematic = false; // Assure que le monstre peut bouger avec la physique

        float vitesse = rb.velocity.magnitude; // Prend en compte la vitesse actuelle
        float vitesseMin = _vitesseDeplacement / 10;
        float acceleration = 1.5f;
        float decelerationDistance = 6f;
        float timeout = 10f; // Sécurité
        float timer = 0f;

        while (Vector3.Distance(transform.position, positionCible) > 1f && timer < timeout)
        {
            if (!_peutSeDeplacer) rb.velocity = Vector3.zero;
            else
            {
                timer += Time.deltaTime;
                Vector3 direction = (positionCible - transform.position).normalized;

                if (Vector3.Distance(transform.position, positionCible) < decelerationDistance)
                {
                    vitesse = Mathf.Lerp(vitesse, vitesseMin, Time.deltaTime * acceleration);
                }
                else
                {
                    vitesse = Mathf.Lerp(vitesse, _vitesseDeplacement, Time.deltaTime * .7f);
                }

                rb.velocity = direction * vitesse;
            }

            yield return null;
        }

        if (timer >= timeout)
        {
            Debug.LogWarning("Le monstre semble bloqué, on passe au point suivant.");
        }

        yield return new WaitForSeconds(.5f);

        if (new List<Transform>(_pointsDePatrouille).Contains(_pointsDePatrouilleActuels[0])) ChoisirPointSuivant();
        else _pointsDePatrouilleActuels.RemoveAt(0);
        StartCoroutine(AllerVers(_pointsDePatrouilleActuels[0].position));
        _estDistrait = false;
    }

    public void ReplacerMonstre()
    {
        if (!_aEteActive) return;
        StopAllCoroutines();
        Vector3 position = _pointsDePatrouilleActuels[0].position;
        // Déplace le monstre au point le plus éloigné du joueur
        for (int i = 0; i < _pointsDePatrouille.Length; i++)
        {
            if (Vector3.Distance(_joueur.position, _pointsDePatrouille[i].position) > Vector3.Distance(_joueur.position, _pointsDePatrouille[0].position))
            {
                position = _pointsDePatrouille[i].position;
            }
        }
        transform.position = position;
        StartCoroutine(AllerVers(_pointsDePatrouilleActuels[0].position));
    }

    public void ChangerTaille(float taille)
    {
        transform.localScale = _tailleInitiale * taille;
        _lumiere.intensity = _intensiteLumiereInitiale * taille;
    }
}
