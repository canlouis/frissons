using UnityEngine;
using System.Collections;

[System.Serializable]
public class Dialogue
{
    public string id; // Identifiant unique du dialogue
    public string texte; // Texte du dialogue
    public bool _peutEtreRejoue; // Optionnel : si le dialogue peut être rejoué
    public AudioClip audio; // Optionnel : audio associé au dialogue
    private bool _aEteJoue = false; // Optionnel : si le dialogue a déjà été joué
    private float _dernierJeu = 0f; // Temps du dernier jeu
    private float _cooldown = 20f; // Temps d'attente avant de rejouer

    public void Jouer()
    {
        if (_aEteJoue && !_peutEtreRejoue) return;
        
        if (_peutEtreRejoue)
        {
            if (Time.time - _dernierJeu < _cooldown) return; // Empêche de rejouer avant la fin du cooldown
            _dernierJeu = Time.time;
        }

        // Afficher le texte sous-titre
        GestionnaireSousTitres.instance.AfficherSousTitre(texte);

        // Jouer l'audio s'il existe
        if (audio != null)
        {
            GestionnaireAudio.instance.JouerSon(audio);
        }

        _aEteJoue = true;
    }
}
