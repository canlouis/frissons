using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public class ZonesArret : MonoBehaviour, SauvegardeEtat
{
    [SerializeField] private float _perteChaleur = 4;
    [SerializeField] private ZonesFrissons _zonesFrissons;
    [SerializeField] Volume _volume;
    ChromaticAberration _aberration;
    LensDistortion _distortion;
    bool _zoneCreee = false;
    float _forceTremblement;
    float _frequenceTremblement;

    void Start()
    {
        _forceTremblement = _zonesFrissons.ForceTremblement;
        _frequenceTremblement = _zonesFrissons.FrequenceTremblement;

        // Obtenez la référence à l'effet de vignette
        if (_volume.profile.TryGet<ChromaticAberration>(out _aberration))
        {
            _aberration.intensity.overrideState = true;
        }
        if (_volume.profile.TryGet<LensDistortion>(out _distortion))
        {
            _distortion.intensity.overrideState = true;
        }
    }

    void OnTriggerEnter(Collider other)
    {

        if (other.CompareTag("Joueur"))
        {
            if (GetComponentInParent<Monstre>() != null)
            {
                GestionnaireSousTitres.instance.JouerDialogue("MonstreAttaque");
            }

            GestionChaleur gestionChaleur = other.GetComponent<GestionChaleur>();
            if (gestionChaleur != null)
            {
                if (!_zoneCreee)
                {
                    gestionChaleur.AjouterVitesse("ZoneArret", _perteChaleur, true);
                    _zoneCreee = true;
                }
                else
                {
                    gestionChaleur.DefinirVitesse("ZoneArret", true);
                }
                other.GetComponent<PlayerInput>().enabled = false;
                MouvementCamera mouvementCamera = other.GetComponent<MouvementCamera>();
                mouvementCamera.ActiverDesactiverCameraPrincipale(false, transform.parent);
                mouvementCamera.FaireTremblerCamera(false);
                mouvementCamera.enabled = false;
            }
            StartCoroutine(EffetsVolume(true));
        }
    }

    public Dictionary<string, object> SauvegarderEtat()
    {
        var etat = new Dictionary<string, object>();
        return etat;
    }

    public void RestaurerEtat(Dictionary<string, object> etat)
    {
        _aberration.intensity.value = 0;
        _distortion.intensity.value = 0;
    }

    IEnumerator EffetsVolume(bool activer)
    {
        float valeurAberration = activer ? 0 : 1;
        float cibleAberration = activer ? 1 : 0;
        float valeurDistortion = activer ? 0 : .5f;
        float cibleDistortion = activer ? .5f : 0;
        float tempsEcoule = 0;
        float duree = 1;
        while (tempsEcoule < duree)
        {
            tempsEcoule += Time.deltaTime;
            _aberration.intensity.value = Mathf.Lerp(valeurAberration, cibleAberration, tempsEcoule / duree);
            _distortion.intensity.value = Mathf.Lerp(valeurDistortion, cibleDistortion, tempsEcoule / duree);
            yield return null;
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Joueur"))
        {
            GestionChaleur gestionChaleur = other.GetComponent<GestionChaleur>();
            if (gestionChaleur != null)
            {
                gestionChaleur.DefinirVitesse("ZoneArret", false);
                other.GetComponent<PlayerInput>().enabled = true;
                MouvementCamera mouvementCamera = other.GetComponent<MouvementCamera>();
                mouvementCamera.enabled = true;
                mouvementCamera.ActiverDesactiverCameraPrincipale(true);
                mouvementCamera.FaireTremblerCamera(true, _forceTremblement, _frequenceTremblement);
            }
            StartCoroutine(EffetsVolume(false));
        }
    }
}