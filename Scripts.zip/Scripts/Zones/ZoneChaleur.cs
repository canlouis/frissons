using System.Collections;
using System.Collections.Generic;
using Unity.Mathematics;
using UnityEngine;

public class ZoneChaleur : MonoBehaviour
{
    [SerializeField] private float _chaleur = 10;
    GameObject _joueur;
    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Joueur"))
        {
            _joueur = other.gameObject;
            GestionChaleur gestionChaleur = other.GetComponent<GestionChaleur>();
            gestionChaleur.ModifierVitessePC(-_chaleur);
            gestionChaleur.PeutChangerVitesse = false;

            if (Checkpoint.Instance.DernierCheckpoint != gameObject)
            {
                Checkpoint.Instance.DernierCheckpoint = gameObject; // Met à jour le dernier checkpoint
                Checkpoint.Instance.SauvegarderEtatMonde(other.gameObject); // Sauvegarde l'état du monde et l'inventaire
            }
        }
    }

    void OnTriggerStay(Collider other)
    {
        if (other.CompareTag("Monstre"))
        {
            float rayon = GetComponent<SphereCollider>().radius * transform.localScale.x;
            float distance = Vector3.Distance(transform.position, other.transform.position) - other.GetComponent<SphereCollider>().radius * other.transform.localScale.x;
            float taille = Mathf.Clamp(distance * 2 / rayon - 1, 0, 1);
            if (other.GetComponent<Monstre>())
            {
                other.GetComponent<Monstre>().ChangerTaille(taille);
            }
            else if (other.GetComponent<MonstreCinematique>())
            {
                other.GetComponent<MonstreCinematique>().ChangerTaille(taille);
            }
        }
    }

    public void Desactiver()
    {
        if (_joueur)
        {
            GestionChaleur gestionChaleur = _joueur.GetComponent<GestionChaleur>();
            MouvementJoueur mouvementJoueur = _joueur.GetComponent<MouvementJoueur>();
            if (mouvementJoueur.EnCourse)
            {
                gestionChaleur.ModifierVitessePC(gestionChaleur.VitessePCCourse - gestionChaleur.VitessePCBase);
            }
            else
            {
                gestionChaleur.ModifierVitessePC(gestionChaleur.VitessePCBase);
            }
            gestionChaleur.PeutChangerVitesse = true;
            mouvementJoueur.EnCharge = false;

            if (Monstre.Instance) Monstre.Instance.PeutAjouterJoueur = true;
        }
        gameObject.SetActive(false);
    }

    void OnTriggerExit(Collider other)
    {
        Monstre monstre = other.GetComponent<Monstre>();
        MonstreCinematique monstreCinematique = other.GetComponent<MonstreCinematique>();
        if (monstre != null)
        {
            Debug.Log("Sorti de la zone de chaleur");
            monstre.ChangerTaille(1);
        }
        else if (monstreCinematique != null)
        {
            monstreCinematique.ChangerTaille(1);
        }

        if (other.CompareTag("Joueur"))
        {
            _joueur = null;
            GestionChaleur gestionChaleur = other.GetComponent<GestionChaleur>();
            MouvementJoueur mouvementJoueur = other.GetComponent<MouvementJoueur>();
            gestionChaleur.SortiZone(_chaleur);
            mouvementJoueur.EnCharge = false;

            if (Monstre.Instance) Monstre.Instance.PeutAjouterJoueur = true;
        }
    }
}
