using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ZonesEcoute : MonoBehaviour
{
    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Joueur"))
        {
            Monstre.Instance.JoueurEstDansZoneEcoute = true;
            if (other.GetComponent<MouvementJoueur>().EnCourse)
            {
                Debug.Log("Joueur en course");
                Monstre.Instance.RemplacerPointActuel(other.transform);
            }
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Joueur"))
        {
            Monstre.Instance.JoueurEstDansZoneEcoute = false;
        }
    }
}
