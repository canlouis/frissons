using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ZoneCinematique : MonoBehaviour
{
    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Joueur"))
        {
            GameManager.instance.JouerCinematique("CinematiqueRencontreMonstre");
            gameObject.SetActive(false);
        }
    }
}