using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ZoneMaisonBase : MonoBehaviour
{
    public event Action EstSortiMaison; // Événement pour informer du départ du premier feu
    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Joueur"))
        {
            EstSortiMaison?.Invoke();
            GestionnaireSousTitres.instance.JouerDialogue("IntroRepFroid");
            gameObject.SetActive(false);
        }
    }
}