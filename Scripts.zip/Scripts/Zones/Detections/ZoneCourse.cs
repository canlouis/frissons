using System.Collections;
using UnityEngine;

public class ZoneCourse : MonoBehaviour
{
    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Joueur"))
        {
            GestionnaireControles.instance.MasquerControle("Deposer/JeterObjet");
            StartCoroutine(JoueurEstSorti());
        }
    }

    IEnumerator JoueurEstSorti()
    {
        yield return new WaitForSeconds(1.5f);
        GameManager.instance.estSortiDeZoneCourse = true;
        GestionnaireControles.instance.AfficherControle("Courir");
        gameObject.SetActive(false);
    }
}