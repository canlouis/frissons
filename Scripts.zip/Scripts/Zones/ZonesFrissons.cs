using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ZonesFrissons : MonoBehaviour
{
    [SerializeField] private float _perteChaleur = 4;
    [SerializeField] private float _forceTremblement = 0.5f;
    [SerializeField] private float _frequenceTremblement = 1f;
    bool _zoneCreee = false;
    public float ForceTremblement => _forceTremblement;
    public float FrequenceTremblement => _frequenceTremblement;

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Joueur"))
        {
            if (GetComponentInParent<Monstre>() != null)
            {
                GestionnaireSousTitres.instance.JouerDialogue("MonstreProche");
            }
            
            GestionChaleur gestionChaleur = other.GetComponent<GestionChaleur>();
            if (gestionChaleur != null)
            {
                if (!_zoneCreee)
                {
                    gestionChaleur.AjouterVitesse("ZoneFrissons", _perteChaleur, true);
                    _zoneCreee = true;
                }
                else
                {
                    gestionChaleur.DefinirVitesse("ZoneFrissons", true);
                }
                other.GetComponent<MouvementCamera>().FaireTremblerCamera(true, _forceTremblement, _frequenceTremblement);
            }
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Joueur"))
        {
            GestionChaleur gestionChaleur = other.GetComponent<GestionChaleur>();
            if (gestionChaleur != null)
            {
                gestionChaleur.DefinirVitesse("ZoneFrissons", false);
                other.GetComponent<MouvementCamera>().FaireTremblerCamera(false);
            }
        }
    }
}