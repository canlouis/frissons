using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LimiteFroid : MonoBehaviour
{
    [SerializeField] private float _perteChaleur = 4;

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Joueur"))
        {
            MouvementCamera mouvementCamera = other.GetComponent<MouvementCamera>();
            if (mouvementCamera != null)
            {
                mouvementCamera.FaireTremblerCamera(true);
            }
        }
    }

    void OnTriggerStay(Collider other)
    {
        if (other.CompareTag("Joueur"))
        {
            GestionChaleur gestionChaleur = other.GetComponent<GestionChaleur>();
            if (gestionChaleur != null)
            {
                gestionChaleur.ModifierVitessePC(_perteChaleur);
                gestionChaleur.PeutChangerVitesse = false;
            }
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Joueur"))
        {
            GestionChaleur gestionChaleur = other.GetComponent<GestionChaleur>();
            if (gestionChaleur != null)
            {
                gestionChaleur.SortiZone(-_perteChaleur);
                other.GetComponent<MouvementCamera>().FaireTremblerCamera(false);
            }
        }
    }
}