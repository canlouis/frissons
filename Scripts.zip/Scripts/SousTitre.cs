using System.Collections;
using System.Threading.Tasks;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;

public class SousTitre : MonoBehaviour
{
    private TMP_Text _texte;
    private bool _mourrant = false;
    CanvasGroup _canvasGroup;

    void Awake()
    {
        _canvasGroup = GetComponent<CanvasGroup>();
        _texte = GetComponent<TMP_Text>();
        StartCoroutine(Apparaitre());
    }

    IEnumerator Apparaitre()
    {
        float duration = .3f;
        float elapsedTime = 0f;
        float volume = _texte.color.a;

        while (elapsedTime < duration)
        {
            if (_texte == null) yield break; // Check if CanvasGroup is destroyed during the loop

            elapsedTime += Time.deltaTime;
            float t = elapsedTime / duration;

            _canvasGroup.alpha = Mathf.Lerp(0, volume, t);

            yield return null;
        }

        if (_texte != null)
        {
            _canvasGroup.alpha = volume;
        }
    }

    public IEnumerator Mourrir()
    {
        if (_mourrant) yield break;
        yield return new WaitForSeconds(2f);
        _mourrant = true;

        float duration = .3f;
        float elapsedTime = 0f;
        float volume = _texte.color.a;

        while (elapsedTime < duration)
        {
            if (_texte == null) yield break; // Check if CanvasGroup is destroyed during the loop

            elapsedTime += Time.deltaTime;
            float t = elapsedTime / duration;

            _canvasGroup.alpha = Mathf.Lerp(volume, 0, t);

            yield return null;
        }

        if (_texte != null)
        {
            _canvasGroup.alpha = 0;
        }
        Destroy(gameObject);
        _mourrant = false;
    }

    public void Detruire()
    {
        Destroy(gameObject);
    }
}