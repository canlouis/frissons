using System.Collections.Generic;
using UnityEngine;

public class Allumette : Utilisable, SauvegardeEtat
{
    [SerializeField] private GameObject[] _allumettes;
    int _nbAllumettes;
    private void Awake()
    {
        _typeConsomable = "Flamme";
        _nbAllumettes = _allumettes.Length;
    }

    public Dictionary<string, object> SauvegarderEtat()
    {
        var etat = new Dictionary<string, object>();
        etat["nbAllumettes"] = _nbAllumettes;
        return etat;
    }

    public void RestaurerEtat(Dictionary<string, object> etat)
    {
        _nbAllumettes = (int)etat["nbAllumettes"];
        for (int i = 0; i < _allumettes.Length; i++)
        {
            if (i < _nbAllumettes)
            {
                _allumettes[i].SetActive(true);
            }
            else
            {
                _allumettes[i].SetActive(false);
            }
        }
    }

    override public void Utiliser(InteractionUtilisables joueur)
    {
        base.Utiliser(joueur);
        if (_nbAllumettes > 0)
        {
            _allumettes[_nbAllumettes - 1].SetActive(false);
            GestionnaireAudio.instance.JouerSon(GestionnaireAudio.instance.utiliserAllumette, .4f, .8f, 1.2f, transform.position);
            _nbAllumettes--;
        }
        else
        {
            GestionnaireSousTitres.instance.JouerDialogue("ManqueAllumette");
            _typeConsomable = "null";
        }
    }

    override public void Prendre(InteractionUtilisables joueur)
    {
        GestionnaireAudio.instance.JouerSon(GestionnaireAudio.instance.allumette, 1f, .8f, 1.2f, transform.position);
    }
    override public void Deposer(InteractionUtilisables joueur)
    {
        GestionnaireAudio.instance.JouerSon(GestionnaireAudio.instance.deposerAllumette, 1f, .8f, 1.2f);
    }

    override public void Consommer(InteractionUtilisables joueur)
    {
        base.Consommer(joueur);
    }
}
