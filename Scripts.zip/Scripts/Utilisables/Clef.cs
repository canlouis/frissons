using UnityEngine;

public class Clef : Utilisable
{

    private void Awake()
    {
        _typeConsomable = ("Clef");
    }

    override public void Utiliser(InteractionUtilisables joueur)
    {
        base.Utiliser(joueur);

    }

    public override void Prendre(InteractionUtilisables joueur)
    {
        base.Prendre(joueur);
        GestionnaireSousTitres.instance.JouerDialogue("RepClef");
        GestionnaireAudio.instance.JouerSon(GestionnaireAudio.instance.clef, 1, .8f, 1.2f, transform.position);
    }

    override public void Consommer(InteractionUtilisables joueur)
    {
        base.Consommer(joueur);
    }

   
    override public void Deposer(InteractionUtilisables joueur)
    {
        GestionnaireAudio.instance.JouerSon(GestionnaireAudio.instance.deposerClef, 1, .8f, 1.2f);
    }
}
