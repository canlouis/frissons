using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lampe : Utilisable, SauvegardeEtat
{
    [SerializeField] private AudioClip _allumage;
    [SerializeField] private AudioClip _brule;
    [SerializeField] private AudioClip _eteingnage;
    [SerializeField] private AudioClip _utilisationAllume;
    [SerializeField] private AudioClip _utilisationEteinte;
    [SerializeField] private float _carburantMaximal = 60;
    [SerializeField] private bool _estAllume;
    [SerializeField] private Light _lumiere;
    [SerializeField] private bool _dejaPris;
    [SerializeField] GestionChaleur _gestionChaleur;
    [SerializeField] ParticleSystem _flamme;
    List<float> _enfantsLifetime = new List<float>();

    private float _carburant = 0;
    bool _estLampeMathilde = false;
    public bool estAllume { get => _estAllume; set => _estAllume = value; }
    public float carburant { get => _carburant; set => _carburant = value; }

    [SerializeField] private AudioSource _source;

    protected override void Start()
    {
        base.Start();
        foreach (Transform child in _flamme.transform)
        {
            ParticleSystem.MainModule main = child.GetComponent<ParticleSystem>().main;
            _enfantsLifetime.Add(main.startLifetime.constant);
        }

        if (_estAllume)
        {
            _estAllume = false;
            _estLampeMathilde = true;
            AllumerLampe(null);
            _gestionChaleur.DefinirVitesse("Lampe", false);
            _estLampeMathilde = false;
        }
    }

    public void AllumerLampe(Utilisable autreUtilisable)
    {
        if (_estAllume)
        {
            return;
        }
        if (autreUtilisable is Allumette) autreUtilisable.Utiliser(null);
        if (!_estLampeMathilde) GestionnaireSousTitres.instance.JouerDialogue("IntroAllumerLampe");
        _flamme.Play();
        _gestionChaleur.DefinirVitesse("Lampe", true);
        _estAllume = true;
        // if (_dialogue) _dialogue.AfficherDialogue(0);
        _typeConsomable = "Flamme";
        GestionnaireAudio.instance.JouerSon(_allumage, .8f, 1.2f, .5f, transform.position);
        GestionnaireAudio.instance.JouerSon(_brule, .8f, 1.2f, .5f, transform.position); // faire une fonction pour jouer un son en boucle
        _carburant = _estLampeMathilde ? _carburantMaximal * 3 : _carburantMaximal;
        _lumiere.gameObject.SetActive(true);
        StartCoroutine(BrulerCarburant());
        _source.Play();
        GestionnaireAudio.instance.JouerSon(GestionnaireAudio.instance.feu, .2f, .8f, 1.2f, transform.position);
    }

    override public void Prendre(InteractionUtilisables joueur)
    {
        GestionnaireAudio.instance.JouerSon(GestionnaireAudio.instance.lampe, 1, .8f, 1.2f, transform.position);
        if (_dejaPris) return;
        _dejaPris = true;
        // // if (_dialogue) _dialogue.AfficherDialogue(6);
    }

    override public void Deposer(InteractionUtilisables joueur)
    {
        GestionnaireAudio.instance.JouerSon(GestionnaireAudio.instance.deposerLampe, 1, .8f, 1.2f);
    }

    public void EteindreLampe()
    {
        GestionnaireSousTitres.instance.JouerDialogue("ManqueLampe");
        _flamme.Stop();
        _gestionChaleur.DefinirVitesse("Lampe", false);
        _estAllume = false;
        // // if (_dialogue) _dialogue.AfficherDialogue(1);
        GestionnaireAudio.instance.JouerSon(_eteingnage, .8f, 1.2f, .5f, transform.position);
        // faire une fonction pour arrêter de jouer le son en boucle
        _lumiere.gameObject.SetActive(false);
        _source.Stop();
    }

    public Dictionary<string, object> SauvegarderEtat()
    {
        var etat = new Dictionary<string, object>();
        etat["carburant"] = _carburant;
        etat["estAllume"] = _estAllume;
        return etat;
    }

    public void RestaurerEtat(Dictionary<string, object> etat)
    {
        bool estAllume = (bool)etat["estAllume"];
        _carburant = (float)etat["carburant"];
        if (estAllume) AllumerLampe(null);
        else EteindreLampe();
    }

    override public void Utiliser(InteractionUtilisables joueur)
    {
        if (_carburant > 0)
        {
            // // if (_dialogue) _dialogue.AfficherDialogue(2);
            GestionnaireAudio.instance.JouerSon(_utilisationAllume, .8f, 1.2f, .5f, transform.position);
            return;
        }

        Utilisable autreUtilisable = null;

        if (joueur.utilisableMainDroite == this) autreUtilisable = joueur.utilisableMainGauche;
        else if (joueur.utilisableMainGauche == this) autreUtilisable = joueur.utilisableMainDroite;

        if (!autreUtilisable)
        {
            // // if (_dialogue) _dialogue.AfficherDialogue(3);
            GestionnaireAudio.instance.JouerSon(_utilisationEteinte, .8f, 1.2f, .5f, transform.position);
            return;
        }
        else if (autreUtilisable.typeConsomable == "Flamme")
        {
            if (autreUtilisable is Lampe && !autreUtilisable.GetComponent<Lampe>().estAllume && _estAllume) return;
            AllumerLampe(autreUtilisable);
        }
    }

    override public void Consommer(InteractionUtilisables joueur)
    {
        if (_carburant > 0)
        {
            // // if (_dialogue) _dialogue.AfficherDialogue(4);
            GestionnaireAudio.instance.JouerSon(_utilisationAllume, .8f, 1.2f, .5f, transform.position);
            return;
        }
        // // if (_dialogue) _dialogue.AfficherDialogue(5);
        GestionnaireAudio.instance.JouerSon(_utilisationEteinte, .8f, 1.2f, .5f, transform.position);
    }

    private IEnumerator BrulerCarburant()
    {
        float beforeInstensity = _lumiere.intensity;

        while (_carburant > 0)
        {
            _lumiere.intensity = _carburant / _carburantMaximal * beforeInstensity;
            for (int i = 0; i < _enfantsLifetime.Count; i++)
            {
                ParticleSystem.MainModule main = _flamme.transform.GetChild(i).GetComponent<ParticleSystem>().main;
                main.startLifetime = _enfantsLifetime[i] * _carburant / _carburantMaximal;
            }
            _carburant -= Time.deltaTime;
            yield return null;
        }
        EteindreLampe();
        _lumiere.intensity = beforeInstensity;
    }
}
