using UnityEngine;

public class Buche : Utilisable
{
    private void Awake()
    {
        _typeConsomable = ("Bois");
    }

    override public void Prendre(InteractionUtilisables joueur)
    {
        GestionnaireAudio.instance.JouerSon(GestionnaireAudio.instance.bois, 1, .8f, 1.2f, transform.position);
    }
    override public void Deposer(InteractionUtilisables joueur)
    {
        GestionnaireAudio.instance.JouerSon(GestionnaireAudio.instance.deposerBois, 1, .8f, 1.2f);
    }
    override public void Utiliser(InteractionUtilisables joueur)
    {
        base.Utiliser(joueur);
    }

    override public void Consommer(InteractionUtilisables joueur)
    {
        base.Consommer(joueur);
    }
}
