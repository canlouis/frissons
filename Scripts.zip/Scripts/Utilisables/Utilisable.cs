using UnityEditor;
using UnityEngine;

public class Utilisable : MonoBehaviour
{
    private Outline _contour;
    private Transform _ancre;
    [SerializeField] protected GameObject _scintillement;

    [SerializeField] protected string _typeConsomable;

    [SerializeField] private string _nom;
    [SerializeField] private MeshRenderer _renderer;

    [Header("Sons")]
    [SerializeField] private AudioClip _son_prendre;
    [SerializeField] private AudioClip _son_utilisation;
    [SerializeField] private AudioClip _son_consommation;
    [SerializeField] private AudioClip _son_deposer;
    [SerializeField] private bool _consomationInifini = false;

    public string nom { get => _nom; set => _nom = value; }

    public string typeConsomable { get => _typeConsomable; set => _typeConsomable = value; }
    public AudioClip son_prendre { get => _son_prendre; set => _son_prendre = value; }
    public AudioClip son_deposer { get => _son_deposer; set => _son_deposer = value; }
    public Transform ancre { get => _ancre; set => _ancre = value; }
    public MeshRenderer meshRenderer { get => _renderer; set => _renderer = value; }

    protected virtual void Start()
    {
        _contour = GetComponent<Outline>();
        _ancre = transform.Find("Ancre");
        _contour.enabled = false;
        _scintillement.SetActive(true);
    }

    virtual public void Utiliser(InteractionUtilisables joueur)
    {
        GestionnaireAudio.instance.JouerSon(_son_utilisation, .8f, 1.2f, .5f, transform.position);
    }

    virtual public void Consommer(InteractionUtilisables joueur)
    {
        GestionnaireAudio.instance.JouerSon(_son_consommation, .8f, 1.2f, .5f, transform.position);
        if (!_consomationInifini)
        {
            joueur.SupprimerUtilisable(this);
            gameObject.SetActive(false);
        }
    }
    
    virtual public void Prendre(InteractionUtilisables joueur)
    {
    }

    virtual public void Deposer(InteractionUtilisables joueur)
    {
    }

    public void ActiverContour()
    {
        _contour.enabled = true;
    }

    public void DesactiverContour()
    {
        _contour.enabled = false;
    }
}
