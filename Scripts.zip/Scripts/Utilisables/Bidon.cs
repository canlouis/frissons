using UnityEngine;

public class Bidon : Utilisable
{
    private void Awake()
    {
        _typeConsomable = ("Gaz");
    }

    public override void Prendre(InteractionUtilisables joueur)
    {
        base.Prendre(joueur);
        GestionnaireSousTitres.instance.JouerDialogue("TrouverBidon");
    }
    override public void Utiliser(InteractionUtilisables joueur)
    {
        base.Utiliser(joueur);
    }

    override public void Consommer(InteractionUtilisables joueur)
    {
        base.Consommer(joueur);
    }
}
