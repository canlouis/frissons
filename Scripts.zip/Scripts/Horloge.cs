using UnityEngine;

public class Horloge : MonoBehaviour
{
    [SerializeField] private Transform _aiguilleHeure;
    [SerializeField] private Transform _aiguilleMinute;

    public void MettreAJourAiguilles(float heureActuelle)
    {
        float minuteInterpolée = heureActuelle * 60f; // Convertit en minutes

        // Ajuste la rotation des aiguilles
        float rotationHeure = ((heureActuelle % 12) * 30f) - 90f;  // Départ en bas à 6h
        float rotationMinute = ((minuteInterpolée % 60) * 6f) - 90f; // Départ en haut à 0 min

        _aiguilleHeure.localRotation = Quaternion.Euler(0, 0, -rotationHeure);
        _aiguilleMinute.localRotation = Quaternion.Euler(0, 0, -rotationMinute);
    }

}
