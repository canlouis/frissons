using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InteractionsDiverses : Declencheur, SauvegardeEtat
{
    [SerializeField] string _dialogue;
    bool _aEteDeclanche = false;
    override public void Declencher(InteractionDeclencheurs joueur)
    {
        base.Declencher(joueur);
        // // if (_dialogue) _dialogue.AfficherDialogue(0);
        if (!_aEteDeclanche)
        {
            GestionnaireSousTitres.instance.JouerDialogue(_dialogue);
            _aEteDeclanche = true;
        }
    }

    public Dictionary<string, object> SauvegarderEtat()
    {
        var etat = new Dictionary<string, object>();
        etat["aEteDeclanche"] = _aEteDeclanche;
    
        return etat;
    }

    public void RestaurerEtat(Dictionary<string, object> etat)
    {
        _aEteDeclanche = (bool)etat["aEteDeclanche"];
    }
}
