using UnityEngine;

public class Declencheur : MonoBehaviour
{
    protected Outline _contour;


    [Header("Strings")]
    [SerializeField] protected string _nom;
    // [SerializeField] protected string _dialogueDeclenchement;
    // [SerializeField] protected string _dialogueConsommation;


    [Header("Sons")]
    [SerializeField] protected AudioClip _son_declenchement;
    [SerializeField] protected AudioClip _son_consumer;


    // public List<string> typesConsomable { get => _typesConsomable; set => _typesConsomable = value; }

    public string nom { get => _nom; set => _nom = value; }


    protected virtual void Start()
    {
        _contour = GetComponent<Outline>();
        _contour.enabled = false;
    }

    virtual public void Declencher(InteractionDeclencheurs joueur)
    {
        GestionnaireAudio.instance.JouerSon(_son_declenchement, .8f, 1.2f, .5f, transform.position);
        // if (_dialogue) _dialogue.AfficherDialogue();
    }

    virtual public bool ConsommerUtilisable(Utilisable utilisable)
    {
        // for (int i = 0; i < _typesConsomable.Count; i++)
        // {
        //     string type = _typesConsomable[i];
        //     if (utilisable.typeConsomable != type)
        //     {
        //         GestionnaireAudio.instance.JouerSon(_son_consumer, .8f, 1.2f, .5f, transform.position);
        //         return true;
        //     }
        // }
        return false;
    }

    public void ActiverContour()
    {
        if (_contour) _contour.enabled = true;
    }

    public void DesactiverContour()
    {
        if (_contour) _contour.enabled = false;
    }
}
