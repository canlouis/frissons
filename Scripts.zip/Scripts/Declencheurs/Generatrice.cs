using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Generatrice : Declencheur, SauvegardeEtat
{
    [SerializeField] private AudioClip _allumage;
    [SerializeField] private AudioClip _enRoute;
    [SerializeField] private AudioClip _destruction;
    [SerializeField] private bool _estDetruite = false;
    [SerializeField] private float _tempsAvantDestruction = 5f;
    [SerializeField] private float _dureeGeneratrice = 100f;
    [SerializeField] private ZoneChaleur _zoneChaleur;
    [SerializeField] bool _generatriceDialogues = false;
    private bool _estAllume = false;
    float _carburant = 0;

    [SerializeField] protected List<GameObject> _batiment = new List<GameObject>();
    [SerializeField] protected Light _lumiere;

    [SerializeField] private AudioSource _source;

    protected override void Start()
    {
        base.Start();
        _carburant = _dureeGeneratrice + Random.Range(-20, 20);
    }

    public override void Declencher(InteractionDeclencheurs joueur)
    {
        base.Declencher(joueur);

        if (!_estAllume && _generatriceDialogues)
        {
            GestionnaireSousTitres.instance.JouerDialogue("IntroManqueGaz");
            StartCoroutine(PoursuivreDialogues());
        }
        else if (!_estAllume && !_generatriceDialogues && !_estDetruite)
        {
            GestionnaireSousTitres.instance.JouerDialogue("BesoinGaz");
        }
    }

    IEnumerator PoursuivreDialogues()
    {
        yield return new WaitForSeconds(3f);
        GestionnaireSousTitres.instance.JouerDialogue("IntroObjectifGaz");
    }

    public Dictionary<string, object> SauvegarderEtat()
    {
        var etat = new Dictionary<string, object>();
        etat["estAllume"] = _estAllume;
        etat["estDetruite"] = _estDetruite;
        etat["carburant"] = _carburant;
        return etat;
    }

    public void RestaurerEtat(Dictionary<string, object> etat)
    {
        bool estAllume = (bool)etat["estAllume"];
        _estDetruite = (bool)etat["estDetruite"];
        _carburant = (float)etat["carburant"];
        StopAllCoroutines();
        if (estAllume) StartCoroutine(CoroutineGeneratrice());
    }

    override public bool ConsommerUtilisable(Utilisable utilisable)
    {
        if (_estAllume) return false;
        if (_estDetruite)
        {
            // // if (_dialogue) _dialogue.AfficherDialogue(1);
            return false;
        }
        if (utilisable.typeConsomable == "Gaz")
        {
            Activer();
            return true;
        }
        // // if (!_estDetruite) { if (_dialogue) _dialogue.AfficherDialogue(0); }
        return false;
    }

    private void Activer()
    {
        GestionnaireSousTitres.instance.JouerDialogue("AllumerGeneratrice");
        _zoneChaleur.gameObject.SetActive(true);
        // // if (_dialogue) _dialogue.AfficherDialogue(2);
        GestionnaireAudio.instance.JouerSon(_son_consumer, .8f, 1.2f, .5f, transform.position);
        _estAllume = true;
        GestionnaireAudio.instance.JouerSon(GestionnaireAudio.instance.generatrice, 1f, .8f, 1.2f, transform.position);
        _source.Play();

        for (int i = 0; i < _batiment.Count; i++)
        {
            GameObject batiment = _batiment[i];
            batiment.SetActive(true);
        }
        _lumiere.color = Color.green;

        StartCoroutine(CoroutineGeneratrice());
    }

    public void DetruireGeneratrice()
    {
        // le monstre va détruire la génératrice
        GestionnaireAudio.instance.JouerSon(_destruction, .8f, 1.2f, .5f, transform.position);
        GestionnaireSousTitres.instance.JouerDialogue("GeneratriceDetruite");
        Debug.Log("Generatrice détruite");
        // faire une fonction pour arrêter de jouer le son en boucle
        _estAllume = false;
        _estDetruite = true;
        for (int i = 0; i < _batiment.Count; i++)
        {
            GameObject batiment = _batiment[i];
            batiment.SetActive(false);
        }
        GestionnaireAudio.instance.JouerSon(GestionnaireAudio.instance.generatriceDetruite, 1f, .8f, 1.2f, transform.position);
        _source.Stop();
        _lumiere.color = Color.black;
        Monstre.Instance.PeutSeDeplacer = true;
        Monstre.Instance.EstDistrait = false;
        _zoneChaleur.gameObject.SetActive(false);
    }

    private void ReinitialiserGeneratrice()
    {
        // faire une fonction pour arrêter de jouer le son en boucle
        for (int i = 0; i < _batiment.Count; i++)
        {
            GameObject batiment = _batiment[i];
            batiment.SetActive(false);
        }
        _lumiere.color = Color.red;
        Monstre.Instance.PeutSeDeplacer = true;
        Monstre.Instance.EstDistrait = false;
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Monstre"))
        {
            if (_estDetruite || !_estAllume) return;
            Monstre.Instance.PeutSeDeplacer = false;
            StartCoroutine(DetruireGeneratriceCoroutine());
        }
    }

    IEnumerator CoroutineGeneratrice()
    {
        while (_carburant > 0)
        {
            _carburant -= Time.deltaTime;
            yield return null;
        }
        Monstre.Instance.RemplacerPointActuel(transform);
    }

    IEnumerator DetruireGeneratriceCoroutine()
    {
        yield return new WaitForSeconds(_tempsAvantDestruction);
        DetruireGeneratrice();
    }
}