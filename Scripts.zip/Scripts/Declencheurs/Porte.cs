using System.Collections;
using System.Collections.Generic;
using System.Xml.Schema;
using UnityEngine;

public class Porte : Declencheur, SauvegardeEtat
{
    [SerializeField] private AudioClip _ouvrir;
    [SerializeField] private AudioClip _fermer;
    [SerializeField] private AudioClip _verouille;
    [SerializeField] private AudioClip _deverouiller;
    [SerializeField] private bool _estVerrouille = false;
    [SerializeField] private bool _estBloque = false;
    [SerializeField] private bool _estOuverte = false;
    [SerializeField] private int _sens = 1;
    [SerializeField] private bool _porteDebut = false;
    public bool estOuverte { get => _estOuverte; set => _estOuverte = value; }
    public bool estVerrouille { get => _estVerrouille; set => _estVerrouille = value; }

    private Collider _collider;

    protected override void Start()
    {
        base.Start();
        // _dialogue = GetComponent<Dialogue>();
        _contour = GetComponent<Outline>();
        _collider = GetComponent<Collider>();
        _contour.enabled = false;
    }

    public Dictionary<string, object> SauvegarderEtat()
    {
        var etat = new Dictionary<string, object>();
        etat["estVerrouille"] = _estVerrouille;
        etat["estBloque"] = _estBloque;
        etat["estOuverte"] = _estOuverte;
        etat["rotation"] = transform.rotation;
        return etat;
    }

    public void RestaurerEtat(Dictionary<string, object> etat)
    {
        _estVerrouille = (bool)etat["estVerrouille"];
        _estBloque = (bool)etat["estBloque"];
        _estOuverte = (bool)etat["estOuverte"];
        transform.rotation = (Quaternion)etat["rotation"];
    }

    override public void Declencher(InteractionDeclencheurs joueur)
    {
        base.Declencher(joueur);
        if(_porteDebut){
            GestionnaireSousTitres.instance.JouerDialogue("RepPorteGelee");
        }
        if (_estBloque)
        {
            return;
        }
        else if (_estVerrouille)
        {
            GestionnaireAudio.instance.JouerSon(_verouille, .8f, 1.2f, .5f, transform.position);
            return;
        }

        GestionnaireAudio.instance.JouerSon(_ouvrir, .8f, 1.2f, .5f, transform.position);
        Ouvrir();
    }

    override public bool ConsommerUtilisable(Utilisable utilisable)
    {
        if (_estBloque)
        {
            return false;
        }

        if (utilisable.typeConsomable == "Clef" && _estVerrouille)
        {
            GestionnaireAudio.instance.JouerSon(_deverouiller, .8f, 1.2f, .5f, transform.position);
            Ouvrir();
            _estVerrouille = false;
            nom = "Porte non-vérouillée";
            return true;
        }
        return false;
    }

    private void Ouvrir()
    {
        if (_estOuverte)
        {
            GestionnaireAudio.instance.JouerSon(_fermer, .8f, 1.2f, .5f, transform.position);
            _collider.isTrigger = false;
            transform.Rotate(0, -90 * _sens, 0);
            // jouer l'animation d'ouverture
        }
        else
        {
            GestionnaireAudio.instance.JouerSon(_ouvrir, .8f, 1.2f, .5f, transform.position);
            _collider.isTrigger = true;
            transform.Rotate(0, 90 * _sens, 0);
            // jouer l'animation de fermeture
        }
        _estOuverte = !_estOuverte;
    }
}
