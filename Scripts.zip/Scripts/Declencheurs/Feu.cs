using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Feu : Declencheur, SauvegardeEtat
{
    [SerializeField] private AudioClip _allumage;
    [SerializeField] private AudioClip _brule;
    [SerializeField] private AudioClip _bucheEteint;
    [SerializeField] private AudioClip _bucheAllume;

    [SerializeField] private bool _estAllume = false;
    [SerializeField] private int _carburantParBuche = 30;
    [SerializeField] private GameObject _pointDeSauvegarde;
    [SerializeField] private Transform _flamme;
    [SerializeField] private ParticleSystem _fumee;
    [SerializeField] private bool _peutLancerCinematique = true;
    public event Action APartiPremierFeu; // Événement pour informer d'un changement de cinématique
    private float _carburant = 0;
    List<float> _enfantsLifetime = new List<float>();
    List<float> _enfantsSize = new List<float>();

    [SerializeField] GameObject[] _buches;
    private int _nbBucheMax = 5;
    int _nbBucheActuel = 0;
    float _intensiteLumiereInitiale;
    Transform _childParticles;

    bool _premierFeu = true;
    [SerializeField] private AudioSource _source;

    protected override void Start()
    {
        base.Start();
        _nbBucheMax = _buches.Length;
        foreach (GameObject buche in _buches)
        {
            buche.SetActive(false);
        }

        _childParticles = _flamme.GetChild(0);
        _intensiteLumiereInitiale = _flamme.GetComponent<Light>().intensity;
        foreach (Transform child in _childParticles)
        {
            ParticleSystem.MainModule main = child.GetComponent<ParticleSystem>().main;
            _enfantsLifetime.Add(main.startLifetime.constant);
            _enfantsSize.Add(main.startSize.constant);
        }
    }

    override public void Declencher(InteractionDeclencheurs joueur)
    {
        base.Declencher(joueur);
        if (_estAllume) return;

        if (_carburant > 0) GestionnaireSousTitres.instance.JouerDialogue("BesoinFlamme");
        else GestionnaireSousTitres.instance.JouerDialogue("BesoinBois");
    }

    public Dictionary<string, object> SauvegarderEtat()
    {
        var etat = new Dictionary<string, object>();
        etat["estAllume"] = _estAllume;
        etat["carburant"] = _carburant;
        return etat;
    }

    public void RestaurerEtat(Dictionary<string, object> etat)
    {
        bool estAllume = (bool)etat["estAllume"];
        _carburant = (float)etat["carburant"];
        if (estAllume)
        {
            StopAllCoroutines();
            EteindreFeu();
            AllumerFeu();
        }

        foreach (GameObject buche in _buches)
        {
            buche.SetActive(false);
        }
        for (int i = 0; i < Mathf.Ceil((float)_carburant / (float)_carburantParBuche); i++)
        {
            _buches[i].SetActive(true);
        }
    }
    override public bool ConsommerUtilisable(Utilisable utilisable)
    {
        if (utilisable.typeConsomable == "Bois")
        {
            if (_nbBucheActuel < _nbBucheMax)
            {
                _buches[_nbBucheActuel].SetActive(true);
                _nbBucheActuel++;
            }
            else
            {
                GestionnaireSousTitres.instance.JouerDialogue("TropBois");
                return false;
            }

            GestionnaireAudio.instance.JouerSon(_son_consumer, .8f, 1.2f, .5f, transform.position);
            _carburant += _carburantParBuche;
            if (_carburant > 0) GestionnaireAudio.instance.JouerSon(_bucheAllume, .8f, 1.2f, .5f, transform.position);
            GestionnaireAudio.instance.JouerSon(_bucheEteint, .8f, 1.2f, .5f, transform.position);
            return true;
        }
        else if (utilisable.typeConsomable == "Flamme")
        {
            if (_carburant > 0)
            {
                if (_estAllume && utilisable is Lampe)
                {
                    // if (!((Lampe)utilisable).estAllume) _carburant -= _carburantParBuche;
                    ((Lampe)utilisable).AllumerLampe(null);
                }
                if (utilisable is Lampe && utilisable.GetComponent<Lampe>().estAllume)
                {
                    // if (!_estAllume) utilisable.GetComponent<Lampe>().carburant -= _carburantParBuche;
                    AllumerFeu();
                }
                else if (!_estAllume && utilisable is Allumette)
                {
                    utilisable.Utiliser(null);
                    AllumerFeu();
                }
                return true;
            }
            // // if (_dialogue) _dialogue.AfficherDialogue(0);
        }
        else
        {
            if (_carburant > 0)
            {
                // // if (_dialogue) _dialogue.AfficherDialogue(0);
                return false;
            }
            // // if (_dialogue) _dialogue.AfficherDialogue(2);
        }
        return false;
    }

    private void AllumerFeu()
    {
        if (_estAllume) return;
        if (_fumee) _fumee.Play();
        if (_premierFeu)
        {
            if (APartiPremierFeu != null)
            {
                APartiPremierFeu.Invoke();
            }
            GestionnaireSousTitres.instance.JouerDialogue("IntroAllumerFeu");
            StartCoroutine(SuiteDialogueDebut());
            _premierFeu = false;
        }
        GestionnaireSousTitres.instance.JouerDialogue("AllumerFeu");
        if (GameManager.instance.aJoueCinematiqueRencontrerMonstre && !GameManager.instance.aJoueCinematiqueFaiblesseMonstre && _peutLancerCinematique)
        {
            GameManager.instance.JouerCinematique("CinematiqueMonstreFaiblesse");
            GameManager.instance.aJoueCinematiqueFaiblesseMonstre = true;
        }
        _estAllume = true;
        // // if (_dialogue) _dialogue.AfficherDialogue(1);
        GestionnaireAudio.instance.JouerSon(_allumage, .8f, 1.2f, .5f, transform.position);
        _flamme.gameObject.SetActive(true);
        _pointDeSauvegarde.SetActive(true); // faire en sorte que lors de la réactivation d'un même checkpoint, la sauvegarde est écrasé
        GestionnaireAudio.instance.JouerSon(GestionnaireAudio.instance.feu, 1f, .8f, 1.2f, transform.position);
        _source.Play();
        StartCoroutine(BrulerCarburant());
    }

    IEnumerator SuiteDialogueDebut()
    {
        yield return new WaitForSeconds(3f);
        GestionnaireSousTitres.instance.JouerDialogue("IntroRepBuche");
        yield return new WaitForSeconds(3f);
        GestionnaireSousTitres.instance.JouerDialogue("IntroObjectifGeneratrice");
    }

    private void EteindreFeu()
    {
        _estAllume = false;
        _flamme.gameObject.SetActive(false);
        foreach (GameObject buche in _buches)
        {
            buche.SetActive(false);
        }
        if (_fumee) _fumee.Stop();
        _pointDeSauvegarde.GetComponent<ZoneChaleur>().Desactiver(); //faudrait garder la sauvegarde même si le feu est éteint (genre le fait que le feu était allumé).
        _source.Stop();
        // faire une fonction pour arrêter de jouer le son en boucle
    }

    private IEnumerator BrulerCarburant()
    {
        Debug.Log("NbBuchesActuelles" +_nbBucheActuel); 
        Debug.Log("Brûler carburant" + Mathf.Ceil(_carburant / (float)_carburantParBuche));
        while (_carburant > 0)
        {
            float nbBuches = Mathf.Ceil(_carburant / (float)_carburantParBuche);
            if (_nbBucheActuel > nbBuches)
            {
                _buches[_nbBucheActuel - 1].SetActive(false);
                _nbBucheActuel--;
            }

            foreach (Transform child in _childParticles)
            {
                ParticleSystem.MainModule main = child.GetComponent<ParticleSystem>().main;
                main.startLifetime = _carburant / (_carburantParBuche * 1.5f) * _enfantsLifetime[_childParticles.GetSiblingIndex()];
                main.startSize = _carburant / (_carburantParBuche * 1.5f) * _enfantsSize[_childParticles.GetSiblingIndex()];
            }

            _flamme.GetComponent<Light>().intensity = _carburant / (_carburantParBuche * 1.5f) * _intensiteLumiereInitiale;
            _carburant -= Time.deltaTime;
            yield return null;
        }

        _nbBucheActuel = 0;

        foreach (Transform child in _childParticles)
        {
            ParticleSystem.MainModule main = child.GetComponent<ParticleSystem>().main;
            main.startLifetime = _enfantsLifetime[_childParticles.GetSiblingIndex()];
            main.startSize = _enfantsSize[_childParticles.GetSiblingIndex()];
        }
        _flamme.GetComponent<Light>().intensity = _intensiteLumiereInitiale;
        EteindreFeu();
    }
}
