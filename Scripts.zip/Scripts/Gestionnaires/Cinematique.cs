using UnityEngine;
using UnityEngine.Playables;

[System.Serializable] 

public class Cinematique
{
    public string id;
    public PlayableDirector timeline; // Associe une timeline à la cinématique

    public bool EstTerminee => timeline.state != PlayState.Playing;

    public void Play()
    {
        if (timeline != null)
            timeline.Play();
    }
}
