using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class GestionnaireControles : MonoBehaviour
{
    public static GestionnaireControles instance;

    [System.Serializable]
    public class Controle
    {
        public string nom; // Nom du contrôle
        public CanvasGroup controle; // Référence au CanvasGroup
    }

    [SerializeField] List<Controle> controles; // Liste de contrôles définis dans l'inspecteur
    [SerializeField] float dureeFondu = 0.5f; // Durée du fondu en secondes

    private void Awake()
    {
        if (instance == null)
            instance = this;
        else
            Destroy(gameObject);

        MasquerTous(); // S'assurer que tous les contrôles sont cachés au début
    }

    public void AfficherControle(string nom)
    {
        Controle controle = controles.Find(c => c.nom == nom);
        if (controle != null)
            StartCoroutine(Fondu(controle.controle, true));
    }

    public void MasquerControle(string nom)
    {
        Controle controle = controles.Find(c => c.nom == nom);
        if (controle != null)
            StartCoroutine(Fondu(controle.controle, false));
    }

    public void MasquerTous()
    {
        foreach (var controle in controles)
        {
            controle.controle.alpha = 0;
            controle.controle.gameObject.SetActive(false);
        }
    }

    private IEnumerator Fondu(CanvasGroup canvasGroup, bool apparaitre)
    {
        yield return new WaitForSeconds(1f); // Attendre un peu avant de commencer le fondu

        float duree = 0f;
        float debut = canvasGroup.alpha;
        float fin = apparaitre ? 1f : 0f;

        if (apparaitre)
            canvasGroup.gameObject.SetActive(true);

        while (duree < dureeFondu)
        {
            duree += Time.deltaTime;
            canvasGroup.alpha = Mathf.Lerp(debut, fin, duree / dureeFondu);
            yield return null;
        }

        canvasGroup.alpha = fin;

        if (!apparaitre)
            canvasGroup.gameObject.SetActive(false);
    }
}
