using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class Checkpoint : MonoBehaviour
{
    static Checkpoint _instance;
    public static Checkpoint Instance => _instance;

    private GameObject _dernierCheckpoint; // Dernier checkpoint activé
    private Quaternion _rotationJoueur;
    private List<ObjetEtat> _objetsSauvegardes = new List<ObjetEtat>(); // Objets dans le monde
    private GameObject _objetMainDroite;
    private GameObject _objetMainGauche;

    public GameObject DernierCheckpoint { get => _dernierCheckpoint; set => _dernierCheckpoint = value; }

    void Awake()
    {
        if (_instance == null)
        {
            _instance = this;
        }
        else if (_instance != this)
        {
            Destroy(gameObject);
        }

        _dernierCheckpoint = null;
    }

    public void SauvegarderEtatMonde(GameObject joueur)
    {
        _objetsSauvegardes.Clear();

        InteractionUtilisables inventaireJoueur = joueur.GetComponent<InteractionUtilisables>();

        // Sauvegarde des objets en main
        _objetMainDroite = inventaireJoueur?.utilisableMainDroite ? inventaireJoueur.utilisableMainDroite.gameObject : null;
        _objetMainGauche = inventaireJoueur?.utilisableMainGauche ? inventaireJoueur.utilisableMainGauche.gameObject : null;

        // Sauvegarde la rotation du joueur
        _rotationJoueur = joueur.transform.rotation;

        // Sauvegarde des objets dans le monde
        foreach (Sauvegardable obj in FindObjectsOfType<Sauvegardable>())
        {
            // Si l'objet est tenu en main, il ne doit pas être replacé dans le monde
            if (obj.gameObject == _objetMainDroite || obj.gameObject == _objetMainGauche || !obj.GetComponent<Utilisable>())
            {
                _objetsSauvegardes.Add(new ObjetEtat(obj.gameObject));
                _objetsSauvegardes[_objetsSauvegardes.Count - 1].Replacer = false;
            }
            else
            {
                _objetsSauvegardes.Add(new ObjetEtat(obj.gameObject));
            }
        }
    }

    public void RestaurerDernierCheckpoint(GameObject joueur)
    {
        if (_dernierCheckpoint == null)
        {
            Debug.LogWarning("Aucun checkpoint activé !");
            return;
        }

        // Restaure les objets dans le monde
        foreach (ObjetEtat etat in _objetsSauvegardes)
        {
            etat.ReactiverObjets();
        }

        InteractionUtilisables inventaireJoueur = joueur.GetComponent<InteractionUtilisables>();

        if (inventaireJoueur?.utilisableMainDroite)
        {
            inventaireJoueur.DeposerUtilisable(true);
        }

        if (inventaireJoueur?.utilisableMainGauche)
        {
            inventaireJoueur.DeposerUtilisable(false);
        }

        // Restaure les objets dans le monde
        foreach (ObjetEtat etat in _objetsSauvegardes)
        {
            etat.Restaurer();
        }

        // Restaure les objets en main
        if (inventaireJoueur)
        {
            if (_objetMainDroite) inventaireJoueur.ReinitialiserUtilisables(_objetMainDroite.GetComponent<Utilisable>(), true);
            if (_objetMainGauche) inventaireJoueur.ReinitialiserUtilisables(_objetMainGauche.GetComponent<Utilisable>(), false);
        }


        CharacterController characterController = joueur.GetComponent<CharacterController>();

        if (characterController)
        {
            characterController.enabled = false; // Désactive le CharacterController
            joueur.transform.position = _dernierCheckpoint.transform.position; // Téléporte le joueur
            joueur.transform.rotation = _rotationJoueur; // Restaure la rotation du joueur
            characterController.enabled = true; // Réactive le CharacterController
        }

        joueur.GetComponent<PlayerInput>().enabled = true;
        MouvementCamera mouvementCamera = joueur.GetComponent<MouvementCamera>();
        mouvementCamera.enabled = true;
        mouvementCamera.ActiverDesactiverCameraPrincipale(true);
        mouvementCamera.CiblerCinematique();
        mouvementCamera.FaireTremblerCamera(false);
        joueur.GetComponent<GestionChaleur>().ReinitialiserJoueur();
        joueur.GetComponent<MouvementJoueur>().ReinitialiserJoueur();
        GestionnaireSousTitres.instance.DetruireTousSousTitres();

        if (GameManager.instance.aJoueCinematiqueFaiblesseMonstre) Monstre.Instance.ReplacerMonstre();
    }
}
