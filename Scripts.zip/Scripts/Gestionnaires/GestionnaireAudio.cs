using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GestionnaireAudio : MonoBehaviour
{
    private List<AudioSource> _boucles = new List<AudioSource>();
    static GestionnaireAudio _instance;
    public static GestionnaireAudio instance => _instance;


    [Header("Prefabs")]
    [SerializeField] GameObject _prefabSource;
    [SerializeField] GameObject _prefabBoucle;


    [Header("Sons Pas")]
    [SerializeField] AudioClip[] _neige;
    public AudioClip[] neige { get => _neige; set => _neige = value; }
    [SerializeField] AudioClip[] _glace;
    public AudioClip[] glace { get => _glace; set => _glace = value; }
    [SerializeField] AudioClip[] _plancher;
    public AudioClip[] plancher { get => _plancher; set => _plancher = value; }


    [Header("Sons Joueur")]
    [SerializeField] AudioClip _course;
    public AudioClip course { get => _course; set => _course = value; }
    [SerializeField] AudioClip _grelottement;
    public AudioClip grelottement { get => _grelottement; set => _grelottement = value; }
    [SerializeField] AudioClip _soulagement;
    public AudioClip soulagement { get => _soulagement; set => _soulagement = value; }
    [SerializeField] AudioClip _recuperation;
    public AudioClip recuperation { get => _recuperation; set => _recuperation = value; }
    [SerializeField] AudioClip _mort;
    public AudioClip mort { get => _mort; set => _mort = value; }
    [SerializeField] AudioClip _sousTitre;
    public AudioClip sousTitre { get => _sousTitre; set => _sousTitre = value; }


    [Header("Sons Utilisables")]

    [SerializeField] AudioClip _utiliserAllumette;
    public AudioClip utiliserAllumette { get => _utiliserAllumette; set => _utiliserAllumette = value; }

    [SerializeField] AudioClip _prendre;
    public AudioClip prendre { get => _prendre; set => _prendre = value; }
    [SerializeField] AudioClip _clef;
    public AudioClip clef { get => _clef; set => _clef = value; }
    [SerializeField] AudioClip _bois;
    public AudioClip bois { get => _bois; set => _bois = value; }
    [SerializeField] AudioClip _lampe;
    public AudioClip lampe { get => _lampe; set => _lampe = value; }
    [SerializeField] AudioClip _allumette;
    public AudioClip allumette { get => _allumette; set => _allumette = value; }

    [SerializeField] AudioClip _deposer;
    public AudioClip deposer { get => _deposer; set => _deposer = value; }
    [SerializeField] AudioClip _deposerClef;
    public AudioClip deposerClef { get => _deposerClef; set => _deposerClef = value; }
    [SerializeField] AudioClip _deposerBois;
    public AudioClip deposerBois { get => _deposerBois; set => _deposerBois = value; }
    [SerializeField] AudioClip _deposerLampe;
    public AudioClip deposerLampe { get => _deposerLampe; set => _deposerLampe = value; }
    [SerializeField] AudioClip _deposerAllumette;
    public AudioClip deposerAllumette { get => _deposerAllumette; set => _deposerAllumette = value; }


    [Header("Sons Déclencheurs")]
    [SerializeField] AudioClip _invalide;
    public AudioClip invalide { get => _invalide; set => _invalide = value; }

    [SerializeField] AudioClip _ouvrir;
    public AudioClip ouvrir { get => _ouvrir; set => _ouvrir = value; }
    [SerializeField] AudioClip _fermer;
    public AudioClip fermer { get => _fermer; set => _fermer = value; }
    [SerializeField] AudioClip _verouille;
    public AudioClip verouille { get => _verouille; set => _verouille = value; }
    [SerializeField] AudioClip _deverouille;
    public AudioClip deverouille { get => _deverouille; set => _deverouille = value; }
    [SerializeField] AudioClip _bloque;
    public AudioClip bloque { get => _bloque; set => _bloque = value; }

    [SerializeField] AudioClip _feu;
    public AudioClip feu { get => _feu; set => _feu = value; }
    [SerializeField] AudioClip _feuBrule;
    public AudioClip feuBrule { get => _feuBrule; set => _feuBrule = value; }

    [SerializeField] AudioClip _generatrice;
    public AudioClip generatrice { get => _generatrice; set => _generatrice = value; }
    [SerializeField] AudioClip _generatriceAllume;
    public AudioClip generatriceAllume { get => _generatriceAllume; set => _generatriceAllume = value; }
    [SerializeField] AudioClip _generatriceDetruite;
    public AudioClip generatriceDetruite { get => _generatriceDetruite; set => _generatriceDetruite = value; }


    [Header("Ambiant")]
    [SerializeField] AudioClip _exterieur;
    public AudioClip exterieur { get => _exterieur; set => _exterieur = value; }
    [SerializeField] AudioClip _interieur;
    public AudioClip interieur { get => _interieur; set => _interieur = value; }


    void Awake()
    {
        if (DevenirInstanceSingleton() == false) return;
        DontDestroyOnLoad(gameObject);
        JouerBoucle(_exterieur);
    }

    bool DevenirInstanceSingleton()
    {
        if (_instance != null)
        {
            Debug.Log("Il y a déjà une instance de GestionnaireAudio dans la scène");
            Destroy(gameObject);
            return false;
        }
        _instance = this;
        return true;
    }

    public void JouerSon(AudioClip clip, float volume = 1f, float pitchMin = 1, float pitchMax = 1, Vector3 sourcePosition = default)
    {
        if (!clip) return;
        StartCoroutine(CreateSourceFor(clip, Random.Range(pitchMin, pitchMax), volume, sourcePosition));
    }

    public AudioSource JouerBoucle(AudioClip clip, float volume = 1f, float pitchMin = 1, float pitchMax = 1, Vector3 sourcePosition = default)
    {
        if (!clip) return null;
        StartCoroutine(CreateLoopFor(clip, Random.Range(pitchMin, pitchMax), volume, sourcePosition));

        for (int i = 0; i < _boucles.Count; i++)
        {
            AudioSource boucle = _boucles[i];
            if (boucle.clip == clip) return boucle;
        }
        return null;
    }

    public void ArreterBoucle(AudioClip clip)
    {
        if (!clip) return;
        for (int i = 0; i < _boucles.Count; i++)
        {
            AudioSource boucle = _boucles[i];
            if (boucle.clip == clip)
            {
                boucle.Stop();
                _boucles.Remove(boucle);
            }
        }
    }

    public void ArreterBoucle(AudioSource source)
    {
        if (!source) return;
        for (int i = 0; i < _boucles.Count; i++)
        {
            AudioSource boucle = _boucles[i];
            if (boucle == source)
            {
                boucle.Stop();
                _boucles.Remove(boucle);
                Destroy(boucle);
            }
        }
    }

    private IEnumerator CreateSourceFor(AudioClip clip, float pitch, float volume = 1f, Vector3 sourcePosition = default)
    {
        if (!clip) yield break;

        GameObject audioObject = Instantiate(_prefabSource);
        audioObject.transform.position = sourcePosition;
        AudioSource audioSource = audioObject.GetComponent<AudioSource>();

        // Active le mode 3D si la position source n'est pas Vector3.zero
        audioSource.spatialBlend = (sourcePosition != Vector3.zero) ? 1 : 0;
        audioSource.pitch = pitch;
        audioSource.volume = volume;
        audioSource.PlayOneShot(clip);

        yield return new WaitForSeconds(clip.length);
        Destroy(audioObject);
    }

    private IEnumerator CreateLoopFor(AudioClip clip, float pitch, float volume = 1f, Vector3 sourcePosition = default)
    {
        if (!clip) yield break;
        GameObject audioObject = Instantiate(_prefabBoucle);
        audioObject.transform.position = sourcePosition;
        AudioSource audioSource = audioObject.GetComponent<AudioSource>();
        audioSource.loop = true;
        // Active le mode 3D si la position source n'est pas Vector3.zero
        audioSource.spatialBlend = (sourcePosition != Vector3.zero) ? 1 : 0;
        audioSource.pitch = pitch;
        audioSource.volume = volume;
        audioSource.PlayOneShot(clip);
        _boucles.Add(audioSource);
        while (audioSource.isPlaying)
        {
            yield break;
        }
        Destroy(audioObject);
    }
}
