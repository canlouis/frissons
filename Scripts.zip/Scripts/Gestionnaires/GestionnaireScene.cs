using UnityEngine;
using UnityEngine.SceneManagement;

public class GestionnaireScene : MonoBehaviour
{
    GestionnaireScene _instance;
    public GestionnaireScene Instance => _instance;
    
    void Awake()
    {
        if (_instance == null)
        {
            _instance = this;
        }
        else if (_instance != this)
        {
            Destroy(gameObject);
        }
    }

    public void ChangerScene(string nomScene)
    {
        Cursor.lockState = CursorLockMode.None;
        SceneManager.LoadScene(nomScene);
    }
}
