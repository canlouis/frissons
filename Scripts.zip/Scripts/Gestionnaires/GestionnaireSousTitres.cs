using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class GestionnaireSousTitres : MonoBehaviour
{
    static GestionnaireSousTitres _instance;
    public static GestionnaireSousTitres instance => _instance;

    [SerializeField] private TMP_Text _texteInteraction;
    [SerializeField] private int _limiteSousTitres = 2;
    private List<SousTitre> _sousTitres = new List<SousTitre>();

    [Header("PREFABS")]
    [SerializeField] private GameObject prefabSousTitre;

    [Header("Liste des dialogues (assignés dans l'inspecteur)")]
    [SerializeField] private List<Dialogue> listeDialoguesIntro = new List<Dialogue>();
    [SerializeField] private List<Dialogue> listeDialoguesRadio = new List<Dialogue>();
    [SerializeField] private List<Dialogue> listeDialoguesUtilisables = new List<Dialogue>();
    [SerializeField] private List<Dialogue> listeDialoguesDeclencheurs = new List<Dialogue>();
    [SerializeField] private List<Dialogue> listeDialoguesFroid = new List<Dialogue>();
    [SerializeField] private List<Dialogue> listeDialoguesMonstre = new List<Dialogue>();
    [SerializeField] private List<Dialogue> listeDialoguesCinematiques = new List<Dialogue>();
    [SerializeField] private List<Dialogue> listeDialoguesEvenementiels = new List<Dialogue>();

    private Dictionary<string, Dialogue> dialogues = new Dictionary<string, Dialogue>();

    void Awake()
    {
        if (DevenirInstanceSingleton() == false) return;
        InitialiserDialogues();
    }

    bool DevenirInstanceSingleton()
    {
        if (_instance != null)
        {
            Debug.LogWarning("Il y a déjà une instance de GestionnaireSousTitres dans la scène");
            Destroy(gameObject);
            return false;
        }
        _instance = this;
        return true;
    }

    /// <summary>
    /// Charge tous les dialogues dans un dictionnaire au démarrage.
    /// </summary>
    private void InitialiserDialogues()
    {
        RemplirListeDialogue(listeDialoguesIntro);
        RemplirListeDialogue(listeDialoguesRadio);
        RemplirListeDialogue(listeDialoguesUtilisables);
        RemplirListeDialogue(listeDialoguesDeclencheurs);
        RemplirListeDialogue(listeDialoguesFroid);
        RemplirListeDialogue(listeDialoguesMonstre);
        RemplirListeDialogue(listeDialoguesCinematiques);
        RemplirListeDialogue(listeDialoguesEvenementiels);
    }

    void RemplirListeDialogue(List<Dialogue> listeDialogues)
    {
        foreach (Dialogue dialogue in listeDialogues)
        {
            if (!dialogues.ContainsKey(dialogue.id))
            {
                dialogues.Add(dialogue.id, dialogue);
            }
            else
            {
                Debug.LogWarning($"L'ID {dialogue.id} est en double !");
            }
        }
    }

    /// <summary>
    /// Joue un dialogue par son ID.
    /// </summary>
    public void JouerDialogue(string id)
    {
        if (dialogues.TryGetValue(id, out Dialogue dialogue))
        {
            dialogue.Jouer();
        }
        else
        {
            Debug.LogWarning($"Dialogue introuvable : {id}");
        }
    }

    /// <summary>
    /// Affiche un sous-titre.
    /// </summary>
    public void AfficherSousTitre(string texte, float duree = 6f)
    {
        StartCoroutine(InstancierSousTitre(texte, duree));
    }

    /// <summary>
    /// Affiche un texte d'interaction.
    /// </summary>
    public void AfficherInteraction(string texte)
    {
        _texteInteraction.text = texte;
    }

    /// <summary>
    /// Instancie un sous-titre et le fait disparaître après un délai.
    /// </summary>
    private IEnumerator InstancierSousTitre(string texte, float duree = .5f)
    {
        if (string.IsNullOrEmpty(texte)) yield break;

        // Supprime le sous-titre le plus ancien si la limite est atteinte
        if (_sousTitres.Count >= _limiteSousTitres)
        {
            SousTitre sousTitreARemove = _sousTitres[0];
            _sousTitres.RemoveAt(0);
            yield return StartCoroutine(sousTitreARemove.Mourrir());
        }

        // Créer un nouveau sous-titre
        SousTitre sousTitre = Instantiate(prefabSousTitre, transform).GetComponent<SousTitre>();
        TMP_Text composantTexte = sousTitre.GetComponent<TMP_Text>();
        composantTexte.text = texte;
        _sousTitres.Add(sousTitre);

        yield return new WaitForSeconds(duree);

        if (_sousTitres.Contains(sousTitre))
        {
            yield return StartCoroutine(sousTitre.Mourrir());
            _sousTitres.Remove(sousTitre);
        }
    }

    public void DetruireTousSousTitres()
    {
        StopAllCoroutines();
        foreach (SousTitre sousTitre in _sousTitres)
        {
            Destroy(sousTitre.gameObject);
        }
        _sousTitres.Clear();
    }
}
