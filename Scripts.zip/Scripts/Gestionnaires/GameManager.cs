using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class GameManager : MonoBehaviour, SauvegardeEtat
{
    private static GameManager _instance;
    public static GameManager instance => _instance;
    [SerializeField] private List<Cinematique> _cinematiques;
    [SerializeField] private float _tempsAvantLeverJour = 420f;
    [SerializeField] private float _heureDepart = 8f;
    [SerializeField] private float _heureArrivee = 7f;
    [SerializeField] private Horloge[] _horloges;
    [SerializeField] GameObject _lumiere;
    [SerializeField] float _rotMaxLumiere = 45f;
    [SerializeField] private AnimationCurve _interpolationCouleurAmbiante;
    [SerializeField] GestionChaleur _joueur;

    [Header("Deroullement")]
    [SerializeField] private Feu _premierFeu;
    [SerializeField] private Porte _porteMaison;
    [SerializeField] ZoneChaleur _zoneChaleurMaison;
    [SerializeField] ZoneMaisonBase _zoneMaisonBase;

    [Header("Evenements")]
    bool _aJoueCinematiqueRencontrerMonstre = false;
    bool _aJoueCinematiqueFaiblesseMonstre = false;
    bool _estSortiDeZoneCourse = false;
    bool _jourADebute = false;

    public bool estSortiDeZoneCourse { get => _estSortiDeZoneCourse; set => _estSortiDeZoneCourse = value; }
    public bool aJoueCinematiqueFaiblesseMonstre { get => _aJoueCinematiqueFaiblesseMonstre; set => _aJoueCinematiqueFaiblesseMonstre = value; }
    public bool aJoueCinematiqueRencontrerMonstre { get => _aJoueCinematiqueRencontrerMonstre; set => _aJoueCinematiqueRencontrerMonstre = value; }

    private float _heureActuelle;
    float _rotLumiereInitale;
    float _densiteBrouillardInitiale;
    Color _couleurAmbianteInitiale;
    private bool _cinematiqueEnCours = false;
    public float heureActuelle => _heureActuelle;
    public event Action<bool> OnCinematiqueChange; // Événement pour informer d'un changement de cinématique

    private void Awake()
    {
        if (_instance != null && _instance != this)
        {
            Destroy(gameObject);
            return;
        }

        _instance = this;
    }

    void OnAPartiPremierFeu()
    {
        _porteMaison.estVerrouille = false;
        _zoneChaleurMaison.gameObject.SetActive(false);
    }

    public Dictionary<string, object> SauvegarderEtat()
    {
        // Implement the method to save the state
        Dictionary<string, object> etat = new Dictionary<string, object>();
        etat["heureActuelle"] = _heureActuelle;
        return etat;
    }

    public void RestaurerEtat(Dictionary<string, object> etat)
    {
        if (etat.TryGetValue("heureActuelle", out object heureActuelle))
        {
            _heureActuelle = (float)heureActuelle;

            StopAllCoroutines();
            StartCoroutine(LeverJour());
        }
    }


    void Start()
    {
        _premierFeu.APartiPremierFeu += OnAPartiPremierFeu;
        _zoneMaisonBase.EstSortiMaison += () => StartCoroutine(LeverJour());
        _rotLumiereInitale = _lumiere.transform.rotation.eulerAngles.x;
        _densiteBrouillardInitiale = RenderSettings.fogDensity;
        _heureActuelle = _heureDepart;

        // Assurez-vous que la courbe est définie dans l'inspecteur
        if (_interpolationCouleurAmbiante == null)
        {
            _interpolationCouleurAmbiante = AnimationCurve.EaseInOut(0, 0, 1, 1);
        }
        _couleurAmbianteInitiale = RenderSettings.ambientLight;
        RenderSettings.ambientLight = Color.black;
        JouerCinematique("CinematiqueDebut");
    }

    public void JouerCinematique(string id)
    {
        if (_cinematiqueEnCours || _joueur.EstMort) return; // Empêche le déclenchement si une cinématique est déjà en cours
        if (id == "CinematiqueMonstreFaiblesse")
        {
            _aJoueCinematiqueFaiblesseMonstre = true;
        }
        else if (id == "CinematiqueRencontreMonstre")
        {
            _aJoueCinematiqueRencontrerMonstre = true;
        }
        else if (id == "CinematiqueFin")
        {
            StartCoroutine(DialoguesFin());
        }

        Cinematique cinematique = _cinematiques.Find(c => c.id == id);
        if (cinematique != null)
        {
            StartCoroutine(JouerCinematiqueCoroutine(cinematique));
        }
        else
        {
            Debug.LogWarning($"Cinematique '{id}' non trouvée !");
        }
    }

    IEnumerator DialoguesFin()
    {
        yield return new WaitForSeconds(7f);
        GestionnaireSousTitres.instance.JouerDialogue("RepFin");
    }

    private IEnumerator JouerCinematiqueCoroutine(Cinematique cinematique)
    {
        _cinematiqueEnCours = true;
        OnCinematiqueChange?.Invoke(true); // Notifie que la cinématique démarre

        // Joue la cinématique (exemple avec une Timeline)
        cinematique.Play();

        yield return new WaitUntil(() => cinematique.EstTerminee);

        if (cinematique.id == "CinematiqueDebut")
        {
            _zoneChaleurMaison.gameObject.SetActive(true);
            GestionnaireSousTitres.instance.JouerDialogue("IntroPanneCourant");
            yield return new WaitForSeconds(3f);
            GestionnaireSousTitres.instance.JouerDialogue("IntroObjectifLumiere");
        }
        else if (cinematique.id == "CinematiqueRencontreMonstre")
        {
            GestionnaireSousTitres.instance.JouerDialogue("RepRencontreMonstre");
        }
        else if (cinematique.id == "CinematiqueMonstreFaiblesse")
        {
            GestionnaireSousTitres.instance.JouerDialogue("RepMonstreFaiblesse");
            StartCoroutine(SuiteDialogueMonstre());
        }

        _cinematiqueEnCours = false;
        OnCinematiqueChange?.Invoke(false); // Notifie que la cinématique est terminée
    }

    IEnumerator SuiteDialogueMonstre()
    {
        yield return new WaitForSeconds(3f);
        GestionnaireSousTitres.instance.JouerDialogue("RepMatin");
    }

    private IEnumerator LeverJour()
    {
        _jourADebute = true;
        float tempsEcoule = (_heureActuelle - _heureDepart) / (_heureArrivee - _heureDepart) * _tempsAvantLeverJour; // Convertir l'heure en temps écoulé

        while (tempsEcoule < _tempsAvantLeverJour)
        {
            float ratio = tempsEcoule / _tempsAvantLeverJour;

            // Trouver le plus court chemin entre les angles
            float angle = _rotLumiereInitale + Mathf.Lerp(0, Mathf.DeltaAngle(_rotLumiereInitale, _rotMaxLumiere), ratio);
            _lumiere.transform.rotation = Quaternion.Euler(angle, 0, 0);

            // Calculer l'heure actuelle
            _heureActuelle = Mathf.Lerp(_heureDepart, _heureArrivee, ratio);

            // Mettre à jour toutes les horloges enregistrées
            foreach (Horloge horloge in _horloges)
            {
                horloge.MettreAJourAiguilles(_heureActuelle);
            }

            if (_lumiere.transform.rotation.x > 0)
            {
                _lumiere.GetComponent<Light>().cullingMask = LayerMask.GetMask("Nothing");
            }
            else
            {
                _lumiere.GetComponent<Light>().cullingMask = LayerMask.NameToLayer("Everything");
            }

            RenderSettings.fogDensity = Mathf.Lerp(_densiteBrouillardInitiale, 0.01f, ratio);
            float smoothRatio = _interpolationCouleurAmbiante.Evaluate(ratio);
            RenderSettings.ambientLight = Color.Lerp(Color.black, _couleurAmbianteInitiale, smoothRatio);

            tempsEcoule += Time.deltaTime;
            yield return null;
        }

        Victoire();
    }

    void Victoire()
    {
        JouerCinematique("CinematiqueFin");
    }
}
