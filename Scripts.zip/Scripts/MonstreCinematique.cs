using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonstreCinematique : MonoBehaviour
{
    [SerializeField] float _vitesseDeplacement = 10f;
    [SerializeField] GameObject _corpsMonstre;
    Vector3 _tailleInitiale;
    Light _lumiere;
    float _intensiteLumiereInitiale;
    bool _enFin = false;

    void Start()
    {
        _lumiere = GetComponent<Light>();
        _intensiteLumiereInitiale = _lumiere.intensity;
        _tailleInitiale = transform.localScale;
    }

    private IEnumerator AllerVers(Vector3 positionCible)
    {
        Rigidbody rb = GetComponent<Rigidbody>();
        rb.isKinematic = false; // Assure que le monstre peut bouger avec la physique

        float vitesse = rb.velocity.magnitude; // Prend en compte la vitesse actuelle
        float vitesseMin = _vitesseDeplacement / 10;
        float acceleration = 1.5f;
        float decelerationDistance = 6f;
        float timeout = 10f; // Sécurité
        float timer = 0f;

        while (Vector3.Distance(transform.position, positionCible) > 1f && timer < timeout)
        {
            timer += Time.deltaTime;
            Vector3 direction = (positionCible - transform.position).normalized;

            if (Vector3.Distance(transform.position, positionCible) < decelerationDistance)
            {
                vitesse = Mathf.Lerp(vitesse, vitesseMin, Time.deltaTime * acceleration);
            }
            else
            {
                vitesse = Mathf.Lerp(vitesse, _vitesseDeplacement, Time.deltaTime * .7f);
            }

            rb.velocity = direction * vitesse;


            yield return null;
        }

        if (timer >= timeout)
        {
            Debug.LogWarning("Le monstre semble bloqué, on passe au point suivant.");
        }
    }

    public void SeDeplacerVers(Transform positionCible)
    {
        StartCoroutine(AllerVers(positionCible.position));
    }

    public void FaireApparaitreAuPoint(Transform position)
    {
        if (position)
        {
            transform.position = position.position;
            _enFin = true;
        }
    }

    public void ChangerTaille(float taille)
    {
        transform.localScale = _tailleInitiale * taille;
        _lumiere.intensity = _intensiteLumiereInitiale * taille;
    }

    void OnTriggerEnter(Collider other)
    {
        Monstre monstre = other.GetComponent<Monstre>();
        if (monstre)
        {
            monstre.ActiverMonstre();
            _lumiere.enabled = false;
            _corpsMonstre.SetActive(false);
        }

        if (other.GetComponentInParent<ZoneChaleur>() && _enFin)
        {
            StartCoroutine(Fin());
        }
    }

    IEnumerator Fin()
    {
        yield return new WaitForSeconds(1.5f);
        gameObject.SetActive(false);
    }
}
